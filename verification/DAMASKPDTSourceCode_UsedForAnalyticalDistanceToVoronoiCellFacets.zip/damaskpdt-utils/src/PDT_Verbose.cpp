//##MK::GPLV3

#include "PDT_Verbose.h"


//genering global functions to report state, warnings and erros
void reporting( const int rank, const string what )
{
	cout << "VERBOSE::" << rank << " " << what << "\n";
}

void reporting( const string what )
{
	cout << "VERBOSE::" << what << "\n";
}


void complaining( const int rank, const string what )
{
	cout << "WARNING::" << rank << " " << what << "\n";
}

void complaining( const string what )
{
	cout << "WARNING::" << what << "\n";
}


void stopping( const int rank, const string what )
{
	cerr << "ERROR::" << rank << " " << what << "\n";
}

void stopping( const string what )
{
	cerr << "ERROR::" << what << "\n";
}
