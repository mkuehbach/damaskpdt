//##MK::GPLV3


#ifndef __PDT_UTILS_RAPIDXMLINTERFACE_H__
#define __PDT_UTILS_RAPIDXMLINTERFACE_H__

#include "PDT_Parallelization.h"

//add thirdparty XML reader header library functionality by M. Kalicinski
#include "thirdparty/RapidXML/rapidxml.hpp"

using namespace rapidxml;


#endif
