//##MK::GPLV3

#include "PDT_Datatypes.h"


void t3x3::add( const t3x3 & increase, const pdt_real weight )
{
	this->a11 += weight * increase.a11;
	this->a12 += weight * increase.a12;
	this->a13 += weight * increase.a13;

	this->a21 += weight * increase.a21;
	this->a22 += weight * increase.a22;
	this->a23 += weight * increase.a23;

	this->a31 += weight * increase.a31;
	this->a32 += weight * increase.a32;
	this->a33 += weight * increase.a33;
}


void t3x3::div( const pdt_real divisor )
{
	if (abs(divisor) > EPSILON) {
		this->a11 /= divisor;
		this->a12 /= divisor;
		this->a13 /= divisor;

		this->a21 /= divisor;
		this->a22 /= divisor;
		this->a23 /= divisor;

		this->a31 /= divisor;
		this->a32 /= divisor;
		this->a33 /= divisor;
	}
}


pdt_real t3x3::det()
{
	pdt_real row1 = +ONE*this->a11 * ((this->a22*this->a33) - (this->a32*this->a23));
	pdt_real row2 = +ONE*this->a21 * ((this->a12*this->a33) - (this->a32*this->a13));
	pdt_real row3 = +ONE*this->a31 * ((this->a12*this->a23) - (this->a22*this->a13));
	return row1 - row2 + row3;
}


ostream& operator << (ostream& in, t3x3 const & val) {
	in << val.a11 << ";" << val.a12 << ";" << val.a13 << "\n";
	in << val.a21 << ";" << val.a22 << ";" << val.a23 << "\n";
	in << val.a31 << ";" << val.a32 << ";" << val.a33 << "\n";
	return in;
}


p3d p3d::active_rotation_relocate( t3x3 const & R )
{
	return p3d( 	R.a11 * this->x + R.a12 * this->y + R.a13 * this->z,
					R.a21 * this->x + R.a22 * this->y + R.a23 * this->z,
					R.a31 * this->x + R.a32 * this->y + R.a33 * this->z   );
}


pdt_real dot( p3d const & a, p3d const & b )
{
	return a.x*b.x + a.y*b.y + a.z*b.z;
}


p3d cross( p3d const & a, p3d const & b )
{
	return p3d( a.y*b.z - a.z*b.y,
				a.z*b.x - a.x*b.z,
				a.x*b.y - a.y*b.x );
}


pdt_real vnorm( p3d const & a )
{
	return sqrt(SQR(a.x)+SQR(a.y)+SQR(a.z));
}


ostream& operator<<(ostream& in, p3d const & val)
{
	in << val.x << ";" << val.y << ";" << val.z << "\n";
	return in;
}


ostream& operator<<(ostream& in, p3i const & val)
{
	in << val.x << ";" << val.y << ";" << val.z << "\n";
	return in;
}


ostream& operator<<(ostream& in, p3dm1 const & val)
{
	in << val.x << ";" << val.y << ";" << val.z << "--" << val.m << "\n";
	return in;
}


void d3d::normalize_me()
{
	pdt_real norm = ONE / sqrt(SQR(this->u)+SQR(this->v)+SQR(this->w));
	this->u *= norm;
	this->v *= norm;
	this->w *= norm;
}


pdt_real d3d::len()
{
	pdt_real sqrlen = SQR(this->u) + SQR(this->v) + SQR(this->w);
	return ( sqrlen > EPSILON) ? sqrt(sqrlen) : ZERO;
}


ostream& operator<<(ostream& in, d3d const & val)
{
	in << val.u << ";" << val.v << ";" << val.w << "\n";
	return in;
}


inline pdt_real v3d::len() const
{
	return (this->SQR_len > EPSILON) ? sqrt(this->SQR_len) : ZERO;
}


ostream& operator<<(ostream& in, v3d const & val)
{
	in << val.u << ";" << val.v << ";" << val.w << "----" << val.SQR_len << "\n";
	return in;
}


void aabb3d::add_epsilon_guard()
{
	this->xmi -= EPSILON;
	this->xmx += EPSILON;
	this->ymi -= EPSILON;
	this->ymx += EPSILON;
	this->zmi -= EPSILON;
	this->zmx += EPSILON;
}


void aabb3d::scale()
{
	this->xsz = this->xmx - this->xmi;
	this->ysz = this->ymx - this->ymi;
	this->zsz = this->zmx - this->zmi;
}

void aabb3d::blowup( const pdt_real f )
{
	this->xmi -= f;
	this->xmx += f;
	this->ymi -= f;
	this->ymx += f;
	this->zmi -= f;
	this->zmx += f;
	this->scale();
}


pdt_real aabb3d::diag()
{
	return sqrt(SQR(this->xmx-this->xmi)+SQR(this->ymx-this->ymi)+SQR(this->zmx-this->zmi));
}


bool aabb3d::inside( const p3dm1 test )
{
	if ( test.x < this->xmi )	return false;
	if ( test.x > this->xmx )	return false;
	if ( test.y < this->ymi )	return false;
	if ( test.y > this->ymx )	return false;
	if ( test.z < this->zmi )	return false;
	if ( test.z > this->zmx )	return false;

	return true;
}


/*
bool aabb3d::is_inside_box_xy( aabb3d const & reference, pdt_real guard )
{
	if ( 	(reference.xmi - guard) > this->xmi &&
			(reference.xmx + guard) < this->xmx &&
			(reference.ymi - guard) > this->ymi &&
			(reference.ymx + guard) < this->ymx )
		return true;
	else
		return false;
	//&& (reference.zmi - guard) > this->zmi && (reference.zmx + guard) < this->zmx )
}
*/


bool aabb3d::is_inside( p3d const & test ) {
	if ( test.x < this->xmi )
		return false;
	if ( test.x > this->xmx )
		return false;
	if ( test.y < this->ymi )
		return false;
	if ( test.y > this->ymx )
		return false;
	if ( test.z < this->zmi )
		return false;
	if ( test.z > this->zmx )
		return false;

	//not return so on box walls or inside
	return true;
}


p3d aabb3d::center()
{
	return p3d( 0.5*(this->xmi + this->xmx),
				0.5*(this->ymi + this->ymx),
				0.5*(this->zmi + this->zmx) );
}


pdt_real aabb3d::volume()
{
	return 	(this->xmx - this->xmi) *
			(this->ymx - this->ymi) *
			(this->zmx - this->zmi);
}


p3i aabb3d::blockpartitioning( const size_t p_total, const size_t p_perblock_target )
{
	p3i out = p3i( 1, 1, 1);
	if ( this->xsz > EPSILON ) {
		pdt_real yrel = this->ysz / this->xsz;
		pdt_real zrel = this->zsz / this->xsz;
		pdt_real ix = pow(
			(static_cast<pdt_real>(p_total) / p_perblock_target) / (yrel * zrel),
			( static_cast<pdt_real>(1.0)/static_cast<pdt_real>(3.0) ) );

		out.x = ( static_cast<int>(floor(ix)) > 0 ) ? static_cast<int>(floor(ix)) : 1;
		pdt_real iy = yrel * ix;
		out.y = ( static_cast<int>(floor(iy)) > 0 ) ? static_cast<int>(floor(iy)) : 1;
		pdt_real iz = zrel * ix;
		out.z = ( static_cast<int>(floor(iz)) > 0 ) ? static_cast<int>(floor(iz)) : 1;
	}
	return out;
}


void aabb3d::possibly_enlarge_me( const p3d p )
{
	if ( p.x <= this->xmi )
		this->xmi = p.x;
	if ( p.x >= this->xmx )
		this->xmx = p.x;

	if ( p.y <= this->ymi )
		this->ymi = p.y;
	if ( p.y >= this->ymx )
		this->ymx = p.y;

	if ( p.z <= this->zmi )
		this->zmi = p.z;
	if ( p.z >= this->zmx )
		this->zmx = p.z;
}


ostream& operator<<(ostream& in, aabb3d const & val)
{
	in << "\n" << "\t\t" << val.xmi << ";" << val.xmx << "\n";
	in <<         "\t\t" << val.ymi << ";" << val.ymx << "\n";
	in <<         "\t\t" << val.zmi << ";" << val.zmx << "\n";
	in <<         "\t\t" << val.xsz << ";" << val.ysz << ";" << val.zsz << "\n";
	return in;
}


ostream& operator<<(ostream& in, cuboidgrid3d const & val)
{
	in << "Gridcells\t\t" << val.gridcells.xmi << ";" << val.gridcells.xmx << "\n";
	in << "         \t\t" << val.gridcells.ymi << ";" << val.gridcells.ymx << "\n";
	in << "         \t\t" << val.gridcells.zmi << ";" << val.gridcells.zmx << "\n";
	in << "Binwidth \t\t" << val.binwidths.x << ";" << val.binwidths.y << ";" << val.binwidths.z << "\n";
	in << "AABB3D   \t\t" << val.ve.xmi << ";" << val.ve.xmx << ";" << "\n";
	in << "         \t\t" << val.ve.ymi << ";" << val.ve.ymx << ";" << "\n";
	in << "         \t\t" << val.ve.zmi << ";" << val.ve.zmx << "\n";
	return in;
}


/*void cuboidgrid3d::init( const p3i64 extend, const p3d dims, aabb3d const & roi )
{
	this->gridcell = extend;
	this->binwidths = dims;
	this->nxy = extend.nx * extend.ny;
	this->nxyz = extend.nx * extend.ny * extend.nz;
	this->ve = roi;
}*/


p3d cuboidgrid3d::where( const int ix, const int iy, const int iz )
{
	p3d out = p3d( FMX, FMX, FMX ); //failure point
	if ( 	ix >= this->gridcells.xmi &&
			ix <= this->gridcells.xmx &&
			iy >= this->gridcells.ymi &&
			iy <= this->gridcells.ymx &&
			iz >= this->gridcells.zmi &&
			iz <= this->gridcells.zmx ) {

		p3d out = this->ve.center();
		//spreading in steps of binwidths to the six directions axis aligned
		out.x = out.x + (static_cast<pdt_real>(ix) * this->binwidths.x);
		out.y = out.y + (static_cast<pdt_real>(iy) * this->binwidths.y);
		out.z = out.z + (static_cast<pdt_real>(iz) * this->binwidths.z);
		return out;
	}
	return out;
}


size_t cuboidgrid3d::ngridcells()
{
	int nx = this->gridcells.xmx - this->gridcells.xmi + 2; //##MK::+1?
	int ny = this->gridcells.ymx - this->gridcells.ymi + 2; //##MK::+1?
	int nz = this->gridcells.zmx - this->gridcells.zmi + 2; //##MK::+1?
	return static_cast<size_t>(nx) * static_cast<size_t>(ny) * static_cast<size_t>(nz);
}


ostream& operator<<(ostream& in, nbor const & val)
{
	in << "Distance/MarkValue = " << val.d << "\t\t" << val.m << "\n";
	return in;
}



p3d tri3d::barycenter()
{
	return p3d( (this->x1 + this->x2 + this->x3 ) / static_cast<pdt_real>(3.0),
				(this->y1 + this->y2 + this->y3 ) / static_cast<pdt_real>(3.0),
				(this->z1 + this->z2 + this->z3 ) / static_cast<pdt_real>(3.0) );
}


ostream& operator<<(ostream& in, tri3d const & val)
{
	in << val.x1 << ";" << val.y1 << ";" << val.z1 << "\n";
	in << val.x2 << ";" << val.y2 << ";" << val.z2 << "\n";
	in << val.x3 << ";" << val.y3 << ";" << val.z3 << "\n";
	return in;
}

ostream& operator<<(ostream& in, triref3d const & val)
{
	in << val.v1 << "\t\t" << val.v2 << "\t\t" << val.v3 << "\n";
	return in;
}


size_t sqb::where( const p3dm1 p )
{
	//3d implicit x+y*nx+z*nx*ny
	if ( 	p.x >= this->box.xmi &&
			p.x <= this->box.xmx &&
			p.y >= this->box.ymi &&
			p.y <= this->box.ymx &&
			p.z >= this->box.zmi &&
			p.z <= this->box.zmx ) {
		pdt_real ix = floor((p.x - this->box.xmi) / (this->box.xmx - this->box.xmi) * static_cast<pdt_real>(this->nx));
		pdt_real iy = floor((p.y - this->box.ymi) / (this->box.ymx - this->box.ymi) * static_cast<pdt_real>(this->ny));
		pdt_real iz = floor((p.z - this->box.zmi) / (this->box.zmx - this->box.zmi) * static_cast<pdt_real>(this->nz));
		size_t res = static_cast<size_t>(ix) + static_cast<size_t>(iy) * this->nx + static_cast<size_t>(iz) * this->nxy;
		return res;
	}
	return -1;
}


p3d sqb::where( const size_t bxyz )
{
	//3d implicit x+y*nx+z*nx*ny
	size_t bz = bxyz / this->nxy;
	size_t rem = bxyz - bz * this->nxy;
	size_t by = rem / this->nx;
	size_t bx = rem - by*this->nx;
	if ( bx < this->nx && by < this->ny && bz < this->nz ) {
		pdt_real px = this->box.xmi + this->width*(0.5 + static_cast<pdt_real>(bx));
		pdt_real py = this->box.ymi + this->width*(0.5 + static_cast<pdt_real>(by));
		pdt_real pz = this->box.ymi + this->width*(0.5 + static_cast<pdt_real>(by));
		return p3d( px, py, pz );
	}

	return p3d(FMX, FMX, FMX);
}


ostream& operator<<(ostream& in, t3x1 const & val)
{
	in << val.a11 << "," << val.a21 << "," << val.a31 << "\n";
	return in;
}


ostream& operator<<(ostream& in, sqb const & val)
{
	in << "BinningNXYZ/width = " << val.nx << ";" << val.ny << ";" << val.nz << "\t\t" << val.nxy << ";" << val.nxyz << "\t\t" << val.width << "\n";
	in << "BinningBoundingBox = " << val.box << "\n";
	return in;
}
