//##MK::GPLV3


#ifndef __PDT_UTILS_CONFIG_SHARED_H__
#define __PDT_UTILS_CONFIG_SHARED_H__

#include "PDT_KDTree.h"

string read_xml_attribute_string( xml_node<> const * in, const string keyword );
pdt_real read_xml_attribute_real( xml_node<> const * in, const string keyword );
unsigned int read_xml_attribute_uint32( xml_node<> const * in, const string keyword );
int read_xml_attribute_int32( xml_node<> const * in, const string keyword );
bool read_xml_attribute_bool( xml_node<> const * in, const string keyword );
unsigned long read_xml_attribute_uint64( xml_node<> const * in, const string keyword );


class ConfigShared
{
public:

	static unsigned int SimID;
	static unsigned int RndDescrStatsPRNGSeed;
	static unsigned int RndDescrStatsPRNGDiscard;

	//static void readXML( string filename = "" );
	//static bool checkUserInput();
};

#endif
