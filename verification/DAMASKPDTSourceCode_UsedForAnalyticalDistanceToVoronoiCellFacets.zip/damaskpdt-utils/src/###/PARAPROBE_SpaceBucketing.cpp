//##MK::GPLV3


#include "PARAPROBE_SpaceBucketing.h"

spacebucket::spacebucket()
{
	mdat = sqb();
	buckets.clear();
#ifdef SPACEBUCKETING_ACTIVATE_ACCOUNTING
	bucketsinfo.clear();
#endif
}


spacebucket::~spacebucket()
{
	freecontainer();
}


void spacebucket::initcontainer( const aabb3d & container )
{
	//##MK::improve bin definition strategy
	mdat.width = static_cast<apt_real>(SPACEBUCKETING_BINWIDTH);
	apt_real rdim = 0.f;
	size_t idim = 0;

	//identify spatial partitioning
	rdim = ceil(container.xsz / mdat.width);
	idim = static_cast<size_t>(rdim);
	mdat.nx = (idim != 0) ? idim : 1;
	rdim = ceil(container.ysz / mdat.width);
	idim = static_cast<size_t>(rdim);
	mdat.ny = (idim != 0) ? idim : 1;
	rdim = ceil(container.zsz / mdat.width);
	idim = static_cast<size_t>(rdim);
	mdat.nz = (idim != 0) ? idim : 1;

	mdat.nxy = mdat.nx * mdat.ny;
	mdat.nxyz = mdat.nx * mdat.ny * mdat.nz;

	mdat.box = container;

	//fill with empty pointer
	buckets.reserve( mdat.nxyz );
#ifdef SPACEBUCKETING_ACTIVATE_ACCOUNTING
	bucketsinfo.reserve( mdat.nxyz );
#endif
	for( size_t z = 0; z < mdat.nz; ++z ) {	//storing in implicit x,y,z order
		for( size_t y = 0; y < mdat.ny; ++y ) {
			for( size_t x = 0; x < mdat.nx; ++x ) {
				buckets.push_back( NULL );
#ifdef SPACEBUCKETING_ACTIVATE_ACCOUNTING
				bucketsinfo.push_back( NULL );
#endif
			}
		}
	}
}


void spacebucket::freecontainer( void )
{
	size_t nb = buckets.size();
	for(size_t b = 0; b < nb; ++b) {
		delete buckets.at(b);
		buckets.at(b) = NULL;
	}
	//##MK::reset also mdat to when attempting to reutilize data structure
	buckets.clear();

#ifdef SPACEBUCKETING_ACTIVATE_ACCOUNTING
	nb = bucketsinfo.size();
	for(size_t b = 0; b < nb; ++b) {
		delete bucketsinfo.at(b);
		bucketsinfo.at(b) = NULL;
	}
	//##MK::reset also mdat to when attempting to reutilize data structure
	bucketsinfo.clear();
#endif
}



void spacebucket::add_atom( const pos p )
{
	//is point in box which the buckets discretize?
	if ( p.x >= mdat.box.xmi && p.x <= mdat.box.xmx &&
			p.y >= mdat.box.ymi && p.y <= mdat.box.ymx &&
				p.z >= mdat.box.zmi && p.z <= mdat.box.zmx ) { //most likely case
		//in which bucket?
		size_t xx = floor((p.x - mdat.box.xmi) / mdat.box.xsz * static_cast<apt_xyz>(mdat.nx));
		size_t yy = floor((p.y - mdat.box.ymi) / mdat.box.ysz * static_cast<apt_xyz>(mdat.ny));
		size_t zz = floor((p.z - mdat.box.zmi) / mdat.box.zsz * static_cast<apt_xyz>(mdat.nz));

		size_t thisone = xx + yy*mdat.nx + zz*mdat.nxy;

		if ( buckets.at(thisone) != NULL ) { //most likely case until all buckets have been touched
			buckets.at(thisone)->push_back( p );
		}
		else {
			try {
				buckets.at(thisone) = new vector<pos>;
			}
			catch (bad_alloc &ompcroak) {
				complaining( MASTER, "Allocation error in add atom to spacebucket"); return;
			}
			buckets.at(thisone)->push_back( p );
		}
	}
}


#ifdef SPACEBUCKETING_ACTIVATE_ACCOUNTING
void spacebucket::add_atom_info( const pos p, const unsigned short ifo )
{
	//is point in box which the buckets discretize?
	if ( p.x >= mdat.box.xmi && p.x <= mdat.box.xmx &&
			p.y >= mdat.box.ymi && p.y <= mdat.box.ymx &&
				p.z >= mdat.box.zmi && p.z <= mdat.box.zmx ) { //most likely case
		//in which bucket?
		size_t xx = floor((p.x - mdat.box.xmi) / mdat.box.xsz * static_cast<apt_xyz>(mdat.nx));
		size_t yy = floor((p.y - mdat.box.ymi) / mdat.box.ysz * static_cast<apt_xyz>(mdat.ny));
		size_t zz = floor((p.z - mdat.box.zmi) / mdat.box.zsz * static_cast<apt_xyz>(mdat.nz));

		size_t thisone = xx + yy*mdat.nx + zz*mdat.nxy;

		if ( buckets.at(thisone) != NULL ) { //most likely case until all buckets have been touched
			buckets.at(thisone)->push_back( p );
		}
		else {
			try {
				buckets.at(thisone) = new vector<pos>;
			}
			catch (bad_alloc &ompcroak) {
				complaining( MASTER, "Allocation error in add atom info to spacebucket atom part"); return;
			}
			buckets.at(thisone)->push_back( p );
		}

		if ( bucketsinfo.at(thisone) != NULL ) {
			bucketsinfo.at(thisone)->push_back( ifo );
		}
		else {
			try {
				bucketsinfo.at(thisone) = new vector<unsigned short>;
			}
			catch (bad_alloc &ompcroak) {
				complaining( MASTER, "Allocation error in add atom info to spacebucket info part"); return;
			}
			bucketsinfo.at(thisone)->push_back( ifo );
		}
	}
	else { //MK::must not be encountered!
		cerr << "Point pos " << p.x << ";" << p.y << ";" << p.z << " not placed into spatialbucket" << endl;
	}
}
#endif



void spacebucket::range_rball_noclear_nosort( const pos p, apt_xyz r,
		vector<pos> & candidates )
{
	//does neither clear prior processing nor sort the candidates output array
	//which buckets intruded by sphere of radius r at origin p ?
	apt_real xsc = static_cast<apt_real>(mdat.nx) / mdat.box.xsz;
	apt_real ysc = static_cast<apt_real>(mdat.ny) / mdat.box.ysz;
	apt_real zsc = static_cast<apt_real>(mdat.nz) / mdat.box.zsz;

	apt_real outofbox;
	outofbox = p.x - r - mdat.box.xmi;
	size_t sxmi = (outofbox >= 0.0) ? static_cast<size_t>(floor(outofbox*xsc)) : 0;
	outofbox =  mdat.box.xmx - (p.x + r);
	size_t sxmx = (outofbox >= 0.0) ? static_cast<size_t>(floor((p.x + r - mdat.box.xmi)*xsc)) : mdat.nx-1; //exclusive access

	outofbox = p.y - r - mdat.box.ymi;
	size_t symi = (outofbox >= 0.0) ? static_cast<size_t>(floor(outofbox*ysc)) : 0;
	outofbox =  mdat.box.ymx - (p.y + r);
	size_t symx = (outofbox >= 0.0) ? static_cast<size_t>(floor((p.y + r - mdat.box.ymi)*ysc)) : mdat.ny-1; //exclusive access

	outofbox = p.z - r - mdat.box.zmi;
	size_t szmi = (outofbox >= 0.0) ? static_cast<size_t>(floor(outofbox*zsc)) : 0;
	outofbox =  mdat.box.zmx - (p.z + r);
	size_t szmx = (outofbox >= 0.0) ? static_cast<size_t>(floor((p.z + r - mdat.box.zmi)*xsc)) : mdat.nz-1; //exclusive access

	//scan only buckets within [simi,simx]
	for(size_t z = szmi; z <= szmx; ++z) {
		for(size_t y = symi; y <= symx; ++y) {
			for(size_t x = sxmi; x <= sxmx; ++x) {
				size_t thisone = x + y*mdat.nx + z*mdat.nxy;
				if ( buckets.at(thisone) != NULL ) {
					for(auto it = buckets.at(thisone)->begin(); it != buckets.at(thisone)->end(); ++it) {
						if ( (SQR(it->x - p.x) + SQR(it->y - p.y) + SQR(it->z - p.y)) <= SQR(r) ) { //slightly more likely case
							candidates.push_back( *it );
						}
					}
				} //done checking all candidates within this bucket
			}
		}
	}
}


erase_log spacebucket::erase_rball( const p3d p, apt_xyz r )
{
	//deletes all points inside spherical volume of radius r about p
	apt_real xsc = static_cast<apt_real>(mdat.nx) / mdat.box.xsz;
	apt_real ysc = static_cast<apt_real>(mdat.ny) / mdat.box.ysz;
	apt_real zsc = static_cast<apt_real>(mdat.nz) / mdat.box.zsz;

	//##MK::center are in the box so even if r = 0.f p.x at most mdat.box.xmx
	size_t sxmi = ( (p.x-r) > mdat.box.xmi ) ? static_cast<size_t>(floor((p.x-r-mdat.box.xmi)*xsc)) : 0;
	size_t sxmx = ((p.x+r) < mdat.box.xmx) ? static_cast<size_t>(floor((p.x+r-mdat.box.xmi)*xsc)) : mdat.nx-1; //exclusive access

	size_t symi = ( (p.y-r) > mdat.box.ymi ) ? static_cast<size_t>(floor((p.y-r-mdat.box.ymi)*ysc)) : 0;
	size_t symx = ((p.y+r) < mdat.box.ymx) ? static_cast<size_t>(floor((p.y+r-mdat.box.ymi)*ysc)) : mdat.ny-1; //exclusive access

	size_t szmi = ( (p.z-r) > mdat.box.zmi ) ? static_cast<size_t>(floor((p.z-r-mdat.box.zmi)*zsc)) : 0;
	size_t szmx = ((p.z+r) < mdat.box.zmx) ? static_cast<size_t>(floor((p.z+r-mdat.box.zmi)*zsc)) : mdat.nz-1; //exclusive access

	erase_log status = erase_log();

//cout << "sxmi/sxmx\t\t" << sxmi << "\t\t" << sxmx << endl;
//cout << "symi/symx\t\t" << symi << "\t\t" << symx << endl;
//cout << "szmi/szmx\t\t" << szmi << "\t\t" << szmx << endl;

	//scan only buckets within [simi,simx]
	vector<pos> keep;
	for(size_t z = szmi; z <= szmx; ++z) {
		for(size_t y = symi; y <= symx; ++y) {
			for(size_t x = sxmi; x <= sxmx; ++x) {
				size_t thisone = x + y*mdat.nx + z*mdat.nxy;

				if ( buckets.at(thisone) != NULL ) {
					keep.clear();
					for(auto it = buckets.at(thisone)->begin(); it != buckets.at(thisone)->end(); ++it) {
						if ( (SQR(it->x - p.x) + SQR(it->y - p.y) + SQR(it->z - p.z)) <= SQR(r) ) {
							status.ncleared++;
							continue;
						}
						else {
							status.nkept++;
							keep.push_back( *it );
						}
					}
					if ( keep.size() > 0 ) {
						buckets.at(thisone)->clear();
						buckets.at(thisone)->assign( keep.begin(), keep.end() );
					}
				} //done checking all candidates within this bucket
			}
		}
	}

	return status;
}

//##MK::
/*
void spacebucket::write_occupancy_raw()
{
	double tic;
	tic = MPI_Wtime();

	string raw_fn = "PARAPROBE.SimID." + to_string(Settings::SimID) + ".RawdataAlfOccupancy.NX." + to_string(mdat.nx) + ".NY." + to_string(mdat.ny) + ".NZ." + to_string(mdat.nz) + ".raw";

	MPI_File msFileHdl;
	MPI_Status msFileStatus;
	//in mpi.h MPI_Offset is defined as an __int64 which is long long, thus we can jump much more than 2^32 directly when unsigned int would be utilized
	MPI_File_open( MPI_COMM_SELF, raw_fn.c_str(), MPI_MODE_CREATE|MPI_MODE_WRONLY, MPI_INFO_NULL, &msFileHdl );
	long long totalOffset = 0;
	MPI_File_seek( msFileHdl, totalOffset, MPI_SEEK_SET );

	unsigned int* wbuf = NULL;
	try {
		wbuf = new unsigned int[mdat.nxy];
	}
	catch (bad_alloc &hkexc) {
		stopping("Unable to allocate memory for writing labels!");
		return;
	}

	for( size_t z = 0; z < mdat.nz; ++z ) {
		//MK::debug clear labels of buffer to detect inconsistencies
		for ( size_t yx = 0; yx < mdat.nxy; ++yx ) {
			wbuf[yx] = UINT32MX; //debug flagging
			if ( buckets.at(yx+z*mdat.nxy) != NULL ) {
				if ( buckets.at(yx+z*mdat.nxy)->size() < numeric_limits<unsigned int>::max() )
					wbuf[yx] = buckets.at(yx+z*mdat.nxy)->size(); //assure implicit type casting safety...
			}
			else
				wbuf[yx] = 0;
		}
		//xy layer at once
		MPI_File_write(msFileHdl, wbuf, mdat.nxy, MPI_UNSIGNED, &msFileStatus); //implicit advancement of fp
	} //next region z with regions on stacked top of one another in y

	delete [] wbuf; wbuf = NULL;

	MPI_File_close(&msFileHdl); //no Barrier as MPI_COMM_SELF

	double toc = MPI_Wtime();
	cout << "Reporting space bucket bin occupancy written via MPIIO into a binary file in " << (toc-tic) << " seconds" << endl;
}
*/

size_t spacebucket::get_memory_consumption()
{
	size_t bytes = sizeof(sqb);
	for( size_t i = 0; i < buckets.size(); ++i ) {
		bytes += (1+3)*8; //pointer itself and internal pointer of vector
		bytes += buckets.at(i)->size() * sizeof(pos);
	}
#ifdef SPACEBUCKETING_ACTIVATE_ACCOUNTING
	for( size_t i = 0; i < bucketsinfo.size(); ++i) {
		bytes += (1*3)*8;
		bytes += bucketsinfo.at(i)->size() * sizeof(unsigned short);
	}
#endif
	return bytes; //static_cast<double>(bytes) / (1024 * 1024); //MB
}
