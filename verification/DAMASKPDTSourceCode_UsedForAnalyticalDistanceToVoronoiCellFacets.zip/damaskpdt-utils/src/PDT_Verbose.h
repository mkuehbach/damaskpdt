//##MK::GPLV3

#ifndef __PDT_UTILS_VERBOSE_H__
#define __PDT_UTILS_VERBOSE_H__

#include "PDT_STLIncludes.h"
#include "PDT_Numerics.h"
#include "PDT_PhysicalConstants.h"
#include "PDT_UnitConversions.h"
#include "PDT_Parallelization.h"

#include "PDT_BoostInterface.h"
#include "PDT_RapidXMLInterface.h"

//the GITSHA hash will be passed upon compilation using -DGITSHA

/*
#define VERSION_MAJOR				0
#define VERSION_MINOR				1
#define VERSION_REVISION			0
#define VERSION_BETASTAGE			1
bool helloworld( int pargc, char** pargv );
*/

//genering global functions to report state, warnings and erros
void reporting( const int rank, const string what );
void reporting( const string what );
void complaining( const int rank, const string what );
void complaining( const string what );
void stopping( const int rank, const string what );
void stopping( const string what );

#endif
