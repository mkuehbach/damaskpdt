//##MK::GPLV3


#ifndef __PDT_UTILS_DATATYPES_H__
#define __PDT_UTILS_DATATYPES_H__

#include "PDT_Verbose.h"

struct t3x3
{
	pdt_real a11;				//a second order rank tensor with row-column indexing
	pdt_real a12;
	pdt_real a13;
	pdt_real a21;
	pdt_real a22;
	pdt_real a23;
	pdt_real a31;
	pdt_real a32;
	pdt_real a33;
	t3x3() :	a11(ONE), a12(ZERO), a13(ZERO),
				a21(ZERO), a22(ONE), a23(ZERO),
				a31(ZERO), a32(ZERO), a33(ONE) {}	//initialize to identity tensor
	t3x3( const pdt_real* matrix3x3 ) :
				a11(matrix3x3[0]), a12(matrix3x3[1]), a13(matrix3x3[2]),
				a21(matrix3x3[3]), a22(matrix3x3[4]), a23(matrix3x3[5]),
				a31(matrix3x3[6]), a32(matrix3x3[7]), a33(matrix3x3[8]) {}
	t3x3(	const pdt_real _a11, const pdt_real _a12, const pdt_real _a13,
			const pdt_real _a21, const pdt_real _a22, const pdt_real _a23,
			const pdt_real _a31, const pdt_real _a32, const pdt_real _a33 ) :
				a11(_a11), a12(_a12), a13(_a13),
				a21(_a21), a22(_a22), a23(_a23),
				a31(_a31), a32(_a32), a33(_a33) {}
	void add( const t3x3 & increase, const pdt_real weight );
	void div( const pdt_real divisor );
	pdt_real det();
};

ostream& operator << (ostream& in, t3x3 const & val);


struct p3d
{
	pdt_real x;
	pdt_real y;
	pdt_real z;

	p3d() : x(ZERO), y(ZERO), z(ZERO) {}
	p3d(const pdt_real _x, const pdt_real _y, const pdt_real _z) :
		x(_x), y(_y), z(_z) {}
	p3d active_rotation_relocate( t3x3 const & R );
};

ostream& operator<<(ostream& in, p3d const & val);


pdt_real dot( p3d const & a, p3d const & b );
p3d cross( p3d const & a, p3d const & b );
pdt_real vnorm( p3d const & a );


struct p3dm1
{
	pdt_real x;
	pdt_real y;
	pdt_real z;
	unsigned int m;
	unsigned int pad;

	p3dm1() : x(ZERO), y(ZERO), z(ZERO), m(UNKNOWNTYPE), pad(0) {}
	p3dm1(const pdt_real _x, const pdt_real _y, const pdt_real _z, const unsigned int _m ) :
		x(_x), y(_y), z(_z), m(_m), pad(0) {}
	p3dm1(const pdt_real _x, const pdt_real _y, const pdt_real _z, const unsigned int _m, const unsigned int _ifo ) :
			x(_x), y(_y), z(_z), m(_m), pad(_ifo) {}
};

ostream& operator<<(ostream& in, p3dm1 const & val);


struct p3i
{
	int x;
	int y;
	int z;

	p3i() : x(0), y(0), z(0) {}
	p3i(const int _x, const int _y, const int _z) :
		x(_x), y(_y), z(_z) {}
};

ostream& operator<<(ostream& in, p3i const & val);


struct p6i
{
	int xmi;
	int xmx;
	int ymi;
	int ymx;
	int zmi;
	int zmx;
	p6i() : xmi(0), xmx(0), ymi(0), ymx(0), zmi(0), zmx(0) {}
	p6i( const int _xmi, const int _xmx, const int _ymi, const int _ymx, const int _zmi,
		const int _zmx ) : xmi(_xmi), xmx(_xmx), ymi(_ymi), ymx(_ymx), zmi(_zmi), zmx(_zmx) {}
};

ostream& operator<<(ostream& in, p6i const & val);


struct d3d
{
	pdt_real u;
	pdt_real v;
	pdt_real w;
	d3d() : u(ZERO), v(ZERO), w(ZERO) {}
	d3d( const pdt_real _u, const pdt_real _v, const pdt_real _w ) :
		u(_u), v(_v), w(_w) {}

	void normalize_me();
	pdt_real len();
};

ostream& operator<<(ostream& in, d3d const & val);


struct v3d
{
	pdt_real u;
	pdt_real v;
	pdt_real w;
	pdt_real SQR_len;
	v3d() : u(ZERO), v(ZERO), w(ZERO), SQR_len(ZERO) {}
	v3d( const pdt_real _u, const pdt_real _v, const pdt_real _w ) :
		u(_u), v(_v), w(_w), SQR_len( SQR(_u)+SQR(_v)+SQR(_w) ) {}

	inline pdt_real len() const;
};

ostream& operator<<(ostream& in, v3d const & val);


inline bool SortSQRLenAscending( const v3d &aa1, const v3d &aa2)
{
	return aa1.SQR_len < aa2.SQR_len;
}


struct aabb3d
{
	pdt_real xmi;
	pdt_real xmx;
	pdt_real ymi;
	pdt_real ymx;
	pdt_real zmi;
	pdt_real zmx;
	pdt_real xsz;
	pdt_real ysz;
	pdt_real zsz;
	aabb3d() :
		xmi(FMX), xmx(FMI), ymi(FMX), ymx(FMI), zmi(FMX), zmx(FMI), xsz(ZERO), ysz(ZERO), zsz(ZERO)  {}
	aabb3d(const pdt_real _xmi, const pdt_real _xmx, const pdt_real _ymi, const pdt_real _ymx, const pdt_real _zmi, const pdt_real _zmx) :
		xmi(_xmi), xmx(_xmx), ymi(_ymi), ymx(_ymx), zmi(_zmi), zmx(_zmx), xsz(_xmx-_xmi), ysz(_ymx-_ymi), zsz(_zmx-_zmi) {}

	void add_epsilon_guard();
	void scale();
	void blowup( const pdt_real f );
	pdt_real diag();
	bool inside( const p3dm1 test );
	/*
	bool is_inside_box_xy( aabb3d const & reference, pdt_real guard );
	*/
	bool is_inside( p3d const & test );
	p3d center();
	pdt_real volume();
	p3i blockpartitioning( const size_t p_total, const size_t p_perblock_target );
	void possibly_enlarge_me( const p3d p );
};

ostream& operator<<(ostream& in, aabb3d const & val);


struct cuboidgrid3d
{
	//implements metadata to a 3d aggregate of cuboids in the positive octant of Euclidean space
	p6i gridcells;
	p3d binwidths;
	aabb3d ve;				//the cuboid bounding the aggregate

	cuboidgrid3d() : gridcells(p6i()), binwidths(p3d()), ve(aabb3d()) {}

	p3d where( const int ix, const int iy, const int iz );
	size_t ngridcells();
};

ostream& operator<<(ostream& in, cuboidgrid3d const & val);


struct nbor
{
	pdt_real d;
	unsigned int m;
	nbor() : d(RMAX), m(UNKNOWNTYPE) {}
	nbor(const pdt_real _d, const unsigned int _m) : d(_d), m(_m) {}
};

ostream& operator<<(ostream& in, nbor const & val);


inline bool SortNeighborsForAscDistance(const nbor & a, const nbor & b)
{
	return a.d < b.d;
}



struct tri3d
{
	pdt_real x1;
	pdt_real y1;
	pdt_real z1;

	pdt_real x2;
	pdt_real y2;
	pdt_real z2;

	pdt_real x3;
	pdt_real y3;
	pdt_real z3;
	tri3d() : x1(ZERO), y1(ZERO), z1(ZERO), x2(ZERO), y2(ZERO), z2(ZERO), x3(ZERO), y3(ZERO), z3(ZERO) {}
	tri3d( const pdt_real _x1, const pdt_real _y1, const pdt_real _z1,
		const pdt_real _x2, const pdt_real _y2, const pdt_real _z2,
		const pdt_real _x3, const pdt_real _y3, const pdt_real _z3 ) :
		x1(_x1), y1(_y1), z1(_z1),
		x2(_x2), y2(_y2), z2(_z2),
		x3(_x3), y3(_y3), z3(_z3) {}
	p3d barycenter();
};

ostream& operator<<(ostream& in, tri3d const & val);


struct triref3d
{
	int v1; //##MK::consider changing to size or long int...
	int v2;
	int v3;
	triref3d() : v1(0), v2(0), v3(0) {}
	triref3d( const int _v1, const int _v2, const int _v3 ) :
		v1(_v1), v2(_v2), v3(_v3) {}
};

ostream& operator<<(ostream& in, triref3d const & val);


struct sqb
{
	//MK::add reject if binning is too fine thereby exceeding UINT32
	size_t nx;
	size_t ny;
	size_t nz;

	size_t nxy;
	size_t nxyz;
	
	pdt_real width;
	aabb3d box;

	sqb() : nx(1), ny(1), nz(1), nxy(1), nxyz(1), width(FMX), box(aabb3d()) {}
	sqb(const size_t _nx, const size_t _ny, const size_t _nz, const pdt_real _w, const aabb3d _bx) :
		nx(_nx), ny(_ny), nz(_nz), nxy(_nx*_ny), nxyz(_nx*_ny*_nz), width(_w), box(_bx) {}

	size_t where( const p3dm1 p );
	p3d where( const size_t bxyz );
};

ostream& operator<<(ostream& in, sqb const & val);


struct t3x1
{
	pdt_real a11;			//a column vector
	pdt_real a21;
	pdt_real a31;
	t3x1() : 	a11(static_cast<pdt_real>(ZERO)),
				a21(static_cast<pdt_real>(ZERO)),
				a31(static_cast<pdt_real>(ZERO)) {} //initialize to neutral column vector
	t3x1(const pdt_real _a11, const pdt_real _a21, const pdt_real _a31) :
				a11(_a11),
				a21(_a21),
				a31(_a31) {}
};

ostream& operator<<(ostream& in, t3x1 const & val);

#endif
