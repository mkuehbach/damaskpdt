//##MK::GPLV3

#include "CONFIG_Shared.h"

pdt_real str2real( const string str )
{
	return stod( str );
}


string read_xml_attribute_string( xml_node<> const * in, const string keyword )
{
	if ( 0 != in->first_node(keyword.c_str()) ) {
		return in->first_node(keyword.c_str())->value();
	}
	return "";
}


pdt_real read_xml_attribute_real( xml_node<> const * in, const string keyword )
{
	if ( 0 != in->first_node(keyword.c_str()) ) {
		return str2real(in->first_node(keyword.c_str())->value());
	}
	return ZERO;
}


unsigned int read_xml_attribute_uint32( xml_node<> const * in, const string keyword )
{
	if ( 0 != in->first_node(keyword.c_str()) ) {
		return stoul(in->first_node(keyword.c_str())->value());
	}
	return 0;
}


int read_xml_attribute_int32( xml_node<> const * in, const string keyword )
{
	if ( 0 != in->first_node(keyword.c_str()) ) {
		return atoi(in->first_node(keyword.c_str())->value());
	}
	return 0;
}


bool read_xml_attribute_bool( xml_node<> const * in, const string keyword )
{
	if ( 0 != in->first_node(keyword.c_str()) ) {
		int i32 = atoi(in->first_node(keyword.c_str())->value());
		if ( i32 == 1 )
			return true;
		else
			return false;
	}
	return false;
}


unsigned long read_xml_attribute_uint64( xml_node<> const * in, const string keyword )
{
	if ( 0 != in->first_node(keyword.c_str()) ) {
		return stoul(in->first_node(keyword.c_str())->value());
	}
	return 0;
}


unsigned int ConfigShared::SimID = 0;

//predefined values
unsigned int ConfigShared::RndDescrStatsPRNGSeed = -1;
unsigned int ConfigShared::RndDescrStatsPRNGDiscard = 700000;

