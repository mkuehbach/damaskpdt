//##MK::GPLV3

#ifndef __PDT_SYNTHETIC_METADATA_DEFS_H__
#define __PDT_SYNTHETIC_METADATA_DEFS_H__

#define PDT_SYNTH_VOLRECON							"/DAMASKGeom"
#define PDT_SYNTH_VOLRECON_META						"/DAMASKGeom/Metadata"
#define PDT_SYNTH_VOLRECON_META_GRNS				"/DAMASKGeom/Metadata/GrainAggregate"
#define PDT_SYNTH_VOLRECON_META_GRNS_ID				"/DAMASKGeom/Metadata/GrainAggregate/GrainIDs"	//unsigned int
#define PDT_SYNTH_VOLRECON_META_GRNS_ID_NCMAX		1
#define PDT_SYNTH_VOLRECON_META_GRNS_ORI			"/DAMASKGeom/Metadata/GrainAggregate/GrainOrientation" //4x double
#define PDT_SYNTH_VOLRECON_META_GRNS_ORI_NCMAX		4
#define PDT_SYNTH_VOLRECON_META_GRNS_XYZ			"/DAMASKGeom/Metadata/GrainAggregate/GrainXYZ" //3x double
#define PDT_SYNTH_VOLRECON_META_GRNS_XYZ_NCMAX		3
#define PDT_SYNTH_VOLRECON_META_GRNS_VOL			"/DAMASKGeom/Metadata/GrainAggregate/GrainVolumes" //1x double if measured
#define PDT_SYNTH_VOLRECON_META_GRNS_VOL_NCMAX		1


#define PDT_SYNTH_VOLRECON_META_TESS				"/DAMASKGeom/Metadata/PoiVoronoiAggregate"
#define PDT_SYNTH_VOLRECON_META_TESS_TOPO			"/DAMASKGeom/Metadata/PoiVoronoiAggregate/CellFacetTopo" //3x unsigned int
#define PDT_SYNTH_VOLRECON_META_TESS_TOPO_NCMAX	1
#define PDT_SYNTH_VOLRECON_META_TESS_XYZ			"/DAMASKGeom/Metadata/PoiVoronoiAggregate/CellVerticesXYZ" //3x double
#define PDT_SYNTH_VOLRECON_META_TESS_XYZ_NCMAX	3
#define PDT_SYNTH_VOLRECON_META_TESS_HALO			"/DAMASKGeom/Metadata/PoiVoronoiAggregate/CellHaloIDs" //1x int, the neighbors
#define PDT_SYNTH_VOLRECON_META_TESS_HALO_NCMAX	1

#define PDT_SYNTH_VOLRECON_RES						"/DAMASKGeom/Results"
#define PDT_SYNTH_VOLRECON_RES_DIST					"/DAMASKGeom/Results/Distance"
#define PDT_SYNTH_VOLRECON_RES_DIST_NCMAX			1
#define PDT_SYNTH_VOLRECON_RES_TEXID				"/DAMASKGeom/Results/TextureID"
#define PDT_SYNTH_VOLRECON_RES_TEXID_NCMAX			1

#define PDT_SYNTH_VOLRECON_RES_XYZ					"/DAMASKGeom/Results/XYZ" //3x double
#define PDT_SYNTH_VOLRECON_RES_XYZ_NCMAX			3
#define PDT_SYNTH_VOLRECON_RES_TOPO					"/DAMASKGeom/Results/Topo" //1x unsigned int
#define PDT_SYNTH_VOLRECON_RES_TOPO_NCMAX			1

#endif

