//##MK::GPLV3

#ifndef __PDT_UTILS_PARALLELIZATION_H__
#define __PDT_UTILS_PARALLELIZATION_H__

#include <mpi.h>
#include <omp.h>

#define MASTER									0
#define SINGLETHREADED							1
#define	SINGLEPROCESS							1

#define	MPI_COMM_WORLD_OMP_GET_NUM_THREADS		1 //12


//##MK::currently on the RWTH Aachen University cluster include HDF5 library
//#include "hdf5.h"

/*
//##MK::on the MAWS machine potential modification still necessary depending on where the HDF5 file is located user modification 
#include "/usr/local/hdf5/include/hdf5.h"
*/


//implicitly performance affecting choices

//file read ahead system related settings
#define SEQIO_READ_CACHE						((10)*(1024)*(1024)) //bytes
#define MPIIO_READ_CACHE						((10)*(1024)*(1024)) //bytes

#endif
