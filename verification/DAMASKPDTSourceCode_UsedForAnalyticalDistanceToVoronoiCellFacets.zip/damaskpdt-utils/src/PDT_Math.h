//##MK::GPLV3


#ifndef __PDT_UTILS_MATH_H__
#define __PDT_UTILS_MATH_H__

#include "PDT_OriMath.h"

struct circumsphere
{
	pdt_real x;
	pdt_real y;
	pdt_real z;
	pdt_real R;
	circumsphere() : x(ZERO), y(ZERO), z(ZERO), R(ZERO) {}
	circumsphere(const pdt_real _x, const pdt_real _y, const pdt_real _z, const pdt_real _R) :
		x(_x), y(_y), z(_z), R(_R) {}
};

ostream& operator<<(ostream& in, circumsphere const & val);


pdt_real lerp(const pdt_real v0, const pdt_real v1, const pdt_real t);
vector<pdt_real> quantiles_nosort( vector<pdt_real> const & in, vector<pdt_real> const & q );

pdt_real closestPointOnTriangle( const tri3d face, const p3d src );

circumsphere circumsphere_about_triangle( const tri3d tri );


#endif
