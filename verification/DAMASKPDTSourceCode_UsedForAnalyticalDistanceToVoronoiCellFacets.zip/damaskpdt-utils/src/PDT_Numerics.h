//##MK::GPLV3


#ifndef __PDT_UTILS_NUMERICS_H__
#define __PDT_UTILS_NUMERICS_H__

//precision
#define EMPLOY_DOUBLE_PRECISION
typedef double pdt_real;

#define EPSILON							1.0e-12   //(1.0e-6)
#define ZERO							0.0
#define ONE								1.0

//type range
#define UCHARMX							(numeric_limits<unsigned char>::max())
#define UCHARMI							(numeric_limits<unsigned char>::lowest())
#define INT32MX							(numeric_limits<int>::max())
#define INT32MI							(numeric_limits<int>::lowest())
#define UINT64MX						(numeric_limits<size_t>::max())
#define UINT64MI						(numeric_limits<size_t>::lowest())
#define UINT32MX						(numeric_limits<unsigned int>::max())
#define UINT32MI						(numeric_limits<unsigned int>::lowest())
#define UINT16MX						(numeric_limits<unsigned short>::max())
#define UINT16MI						(numeric_limits<unsigned short>::lowest())
#define F32MX							(numeric_limits<apt_xyz>::max())
#define F32MI							(numeric_limits<apt_xyz>::lowest()) //MK::for floating point values numlimits::min is not ::lowest!
#define F64MX							(numeric_limits<double>::max())
#define F64MI							(numeric_limits<double>::lowest())
#define FMX								(F64MX)
#define FMI								(F64MI)
#define SIZETMX							(numeric_limits<size_t>::max())

#define RMIN							(FMI)
#define RMAX							(FMX)

//##MK::unknown type needs to be zero-th type
#define UNKNOWNTYPE						0		    //must be as large to keep the largest type ##MK::(UINT32MX)

//MK::Mersenne initialization
#define MT19937SEED						(-1)
#define MT19937WARMUP					(700000)


#endif
