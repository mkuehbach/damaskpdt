//##MK::GPLV3

#ifndef __PDT_SYNTHETICHDL_H__
#define __PDT_SYNTHETICHDL_H__

#include "PDT_GrainModel.h"


class syntheticHdl
{
	//process-level class which implements the worker instance which synthesizes different virtual APT
	//specimens result are written to a specific HDF5 file

public:
	syntheticHdl();
	~syntheticHdl();

	bool read_damask_oriseeds();

	bool rve_synthesize();
	bool rve_discretize();
	bool rve_distances();
	/*
	bool rve_distances1();
	*/

	bool init_target_file();
	void write_damask_geom();
	void write_distances_to_h5();
	void write_grains_to_h5();

	//void rve_cells_to_h5();


	//void set_mpidatatypes( void );
	//inline int get_rank( void ) { return myRank; }
	//inline int get_nranks( void ) { return nRanks; }
	//void set_rank( const int rr ) { myRank = rr; }
	//void set_nranks( const int nnrr ) { nRanks = nnrr; }

	//xdmfHdl debugxdmfHdl;
	synthetic_h5 debugh5Hdl;
	synthetic_xdmf debugxdmf;

	vector<oriseeds> seeds;
	aabb3d rve;
	vector<p3dm1> geom;
	vector<pdt_real> dist;
	vector<grain> polycrystal;
	//vector<p3dm1> rve27;			//naive copy
	tessHdl tess;

	//profiler synthetic_tictoc;

private:
	//MPI related
	//int myRank;											//my MPI ID in the MPI_COMM_WORLD
	//int nRanks;
};



#endif

