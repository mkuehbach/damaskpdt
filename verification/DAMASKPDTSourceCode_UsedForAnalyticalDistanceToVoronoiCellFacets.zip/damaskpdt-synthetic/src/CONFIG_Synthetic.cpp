//##MK::GPLV3

#include "CONFIG_Synthetic.h"

SYNTHESIS_MODE ConfigSynthetic::SynthesizingMode = SYNTHESIZE_POISSON_VORONOI;
string ConfigSynthetic::InputfileOriSeeds = "";
rve ConfigSynthetic::RVEDimensions = rve();
int ConfigSynthetic::NumberOfSeeds = 0;
size_t ConfigSynthetic::TessellationPointsPerBlock = 5;

bool ConfigSynthetic::readXML( string filename )
{
	if ( 0 == filename.compare("") )
		filename = string("PDT.Input.Debug.xml");

	ifstream file( filename );
	if ( file.fail() ) {
        cerr << "Unable to locate input file " << filename << "\n";
        return false;
    }

	stringstream contents;
	contents << file.rdbuf();
	string xmlDocument(contents.str());

	xml_document<> tree;
	tree.parse<0>(&xmlDocument[0]);

	xml_node<>* rootNode = tree.first_node();
	if (0 != strcmp(rootNode->name(), "ConfigSynthetic")) {
		cerr << "Undefined parameters file!" << "\n";
        return false;
	}

	unsigned int arg = 0;
	unsigned int mode = 0;

	//WHAT TYPE OF ANALYSIS TO DO
	//mode = read_xml_attribute_uint32( rootNode, "SynthesizingMode" );

	SynthesizingMode = SYNTHESIZE_POISSON_VORONOI;

	InputfileOriSeeds = read_xml_attribute_string( rootNode, "InputfileOriSeeds" );

	RVEDimensions = rve( 	read_xml_attribute_uint32( rootNode, "RVENumberOfVoxelX" ),
							read_xml_attribute_real( rootNode, "RVEPhysicalLengthX" ) );
	NumberOfSeeds = read_xml_attribute_int32( rootNode, "NumberOfSeeds" );

	TessellationPointsPerBlock = 5;

	return true;
}


bool ConfigSynthetic::checkUserInput()
{
	cout << "ConfigSynthetic::" << "\n";
	switch (SynthesizingMode)
	{
		case SYNTHESIZE_POISSON_VORONOI:
			cout << "Building Poisson-Voronoi tessellation!" << "\n"; break;
		default:
			cerr << "No synthesis chosen about to quit" << "\n"; return false;
	}
	//cout << "Output written to " << Outputfile << "\n";

	if ( SynthesizingMode == SYNTHESIZE_POISSON_VORONOI ) {

		cout << "InputfileOriSeeds " << InputfileOriSeeds << "\n";
		if ( RVEDimensions.nx < 2 ) {
			cerr << "RVENumberOfVoxelX needs to be at least 2!" << "\n"; return false;
		}
		cout << "RVENumberOfVoxelX " << RVEDimensions.nx << "\n";
		cout << "RVENumberOfVoxelY " << RVEDimensions.ny << "\n";
		cout << "RVENumberOfVoxelZ " << RVEDimensions.nz << "\n";
		cout << "RVENumberOfVoxelXY " << RVEDimensions.nxy << "\n";
		cout << "RVENumberOfVoxelXYZ " << RVEDimensions.nxyz << "\n";

		if ( RVEDimensions.ldx < EPSILON ) {
			cerr << "RVENumberOfVoxelX needs to be positive and at least finite!" << "\n"; return false;
		}
		cout << "RVEPhysicalLengthX " << RVEDimensions.ldx << "\n";
		cout << "RVEPhysicalLengthY " << RVEDimensions.ldy << "\n";
		cout << "RVEPhysicalLengthZ " << RVEDimensions.ldz << "\n";

		if ( NumberOfSeeds < 1 ) {
			cerr << "NumberOfSeeds needs to be at least 1!" << "\n";
		}
		cout << "NumberOfSeeds " << NumberOfSeeds << "\n";
	}

	cout << "TessellationPointsPerBlock " << TessellationPointsPerBlock << "\n";
	cout << "\n";
	return true;
}

