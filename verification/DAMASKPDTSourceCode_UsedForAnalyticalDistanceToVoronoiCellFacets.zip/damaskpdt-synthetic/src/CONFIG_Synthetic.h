//##MK::GPLV3

#ifndef __PDT_CONFIG_SYNTHETIC_H__
#define __PDT_CONFIG_SYNTHETIC_H__

#include "../../damaskpdt-utils/src/CONFIG_Shared.h"


enum SYNTHESIS_MODE {
	SYNTHESIZE_POISSON_VORONOI
};


struct rve
{
	unsigned int nx;
	unsigned int ny;
	unsigned int nz;
	unsigned int nxy;
	unsigned int nxyz;
	pdt_real ldx;
	pdt_real ldy;
	pdt_real ldz;
	rve() : nx(0), ny(0), nz(0), nxy(0), nxyz(0),
			ldx(ZERO), ldy(ZERO), ldz(ZERO) {}
	rve( const unsigned int _nx, const pdt_real _ld ) :
		nx(_nx), ny(_nx), nz(_nx), nxy(SQR(_nx)), nxyz(CUBE(_nx)),
		ldx(_ld), ldy(_ld), ldz(_ld) {}
};



class ConfigSynthetic
{
public:
	
	static SYNTHESIS_MODE SynthesizingMode;
	static string InputfileOriSeeds;
	static rve RVEDimensions;
	static int NumberOfSeeds;

	static size_t TessellationPointsPerBlock;

	static bool readXML( string filename = "" );
	static bool checkUserInput();
};

#endif
