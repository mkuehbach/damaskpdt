//##MK::GPLV3

#ifndef __PDT_SYNTHETIC_TESSELLATION_H__
#define __PDT_SYNTHETIC_TESSELLATION_H__

#include "PDT_SyntheticXDMF.h"


#include "thirdparty/VoroRycroft/voro++-0.4.6/src/voro++.hh"
using namespace voro;

struct distifo
{
	pdt_real d;
	size_t xyz;
	distifo() : d(FMX), xyz(SIZETMX) {}
	distifo( const pdt_real _d, const size_t _xyz ) : d(_d), xyz(_xyz) {}
};


struct oriseeds
{
	pdt_real x;
	pdt_real y;
	pdt_real z;
	pdt_real e1;
	pdt_real e2;
	pdt_real e3;
	pdt_real msid;
	oriseeds() : x(ZERO), y(ZERO), z(ZERO), e1(2*MYPI), e2(2*MYPI), e3(2*MYPI), msid(FMX) {}
	oriseeds( const pdt_real _x, const pdt_real _y, const pdt_real _z,
			const pdt_real _e1, const pdt_real _e2, const pdt_real _e3, const pdt_real _msid ) :
				x(_x), y(_y), z(_z), e1(_e1), e2(_e2), e3(_e3), msid(_msid) {}
};


class tessHdl
{
public:
	tessHdl();
	~tessHdl();

	vector<double> io_geom;
	vector<unsigned int> io_topo;
	vector<int> io_halo;
	vector<voro_io_info> io_info;
};


#endif

