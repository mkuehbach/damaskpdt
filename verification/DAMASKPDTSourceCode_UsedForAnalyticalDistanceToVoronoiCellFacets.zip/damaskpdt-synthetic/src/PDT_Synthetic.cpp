//##MK::GPLV3

#include "PDT_SyntheticHdl.h"


//define what is passed upon execution
#define SIMID									1
#define CONTROLFILE								2


bool init(  int pargc, char** pargv )
{
	ConfigShared::SimID = stoul( pargv[SIMID] );
	try {
		ConfigSynthetic::readXML(pargv[CONTROLFILE]);
	}
	catch (exception& e) {
		cerr << "\n" << "Unable to parse control file! Details:" << "\n" << e.what() << "\n"; return false;
	}
	if ( ConfigSynthetic::checkUserInput() == false ) {
		cerr << "\n" << "Control file settings failed the validity check!" << "\n"; return false;
	}
	else {
		cout << endl << "\t\tInput is valid under SimulationID = " << "SimID." <<  ConfigShared::SimID << endl;
	}
	cout << endl;
	return true;
}


void synthesize_specimens()
{
	//initialize solver and output H5 file
	syntheticHdl* synthetic = NULL;
	try {
		synthetic = new syntheticHdl;
	}
	catch (bad_alloc &exc) {
		cerr << "Unable to allocate a sequential syntheticHdl instance" << "\n";
		delete synthetic; synthetic = NULL; return;
	}
	if ( synthetic->init_target_file() == true ) {
		cout << "Rank " << MASTER << " results file initialized!" << "\n";
	}
	else {
		cerr << "Rank " << MASTER << " results file creation failed!" << "\n";
		delete synthetic; synthetic = NULL; return;
	}

	//build and characterize microstructure
	if ( ConfigSynthetic::SynthesizingMode == SYNTHESIZE_POISSON_VORONOI ) {

		if ( synthetic->read_damask_oriseeds() == true ) {
			cout << "Reading ori/seeds was unsuccessful" << "\n";
		}
		else {
			cerr << "Unable to read ori/seeds a specimen!" << "\n";
			delete synthetic; synthetic = NULL; return;
		}

		if ( synthetic->rve_synthesize() == true ) {
			cout << "Synthetic microstructure created successfully" << "\n";
		}
		else {
			cerr << "Unable to synthesize a specimen!" << "\n";
			delete synthetic; synthetic = NULL; return;
		}
		if ( synthetic->rve_discretize() == true ) {
			cout << "RVE volume discretized successfully" << "\n";
		}
		else {
			cerr << "Unable to discretize RVE volume" << "\n";
			delete synthetic; synthetic = NULL; return;
		}
		if ( synthetic->rve_distances() == true ) {
			cout << "Voxel center to boundary distances computed successfully" << "\n";
		}
		else {
			cerr << "Unable to compute distances" << "\n";
			delete synthetic; synthetic = NULL; return;
		}
	}

	//report results *.geom and *.h5 files
	synthetic->write_damask_geom();
	synthetic->write_distances_to_h5();
	synthetic->write_grains_to_h5();

	//toc = omp_get_wtime();
	//mm = synthetic->synthetic_tictoc.get_memoryconsumption();
	//synthetic->synthetic_tictoc.prof_elpsdtime_and_mem( "WriteSpecimenToAPTH5andXDMF", APT_XX, APT_IS_SEQ, mm, tic, toc);
	//cout << "Writing specimen to APTH5 and XDMF took " << (toc-tic) << " seconds" << "\n";
	//synthetic->synthetic_tictoc.spit_profiling( "Synthetic", ConfigShared::SimID, MASTER );

	//release resources
	delete synthetic; synthetic = NULL;
}


int main(int argc, char** argv)
{
	double tic = omp_get_wtime();
//SETUP PROGRAM AND PARAMETER BUT DO NOT YET LOAD MEASUREMENT DATA
	//helloworld( argc, argv );

	if ( init( argc, argv ) == false ) {
		return 0;
	}

//SETUP MPI PARALLELISM
	//##MK::n/a

//EXECUTE SPECIFIC TASKS
	synthesize_specimens();

//DESTROY MPI
	//##MK::n/a

	double toc = omp_get_wtime();
	//##MK::synthetic_tictoc.
	cout << "damaskpdt-synthetic took " << (toc-tic) << " seconds wall-clock time in total" << endl;

	return 0;
}
