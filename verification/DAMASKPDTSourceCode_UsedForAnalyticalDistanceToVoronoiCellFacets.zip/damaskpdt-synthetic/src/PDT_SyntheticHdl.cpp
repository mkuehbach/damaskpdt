//##MK::GPLV3

#include "PDT_SyntheticHdl.h"


syntheticHdl::syntheticHdl()
{
}


syntheticHdl::~syntheticHdl()
{
}


bool syntheticHdl::read_damask_oriseeds()
{
	double tic = omp_get_wtime();

	ifstream txtfile;
	string txtline;
	//istringstream line;
	//string datapiece;

	txtfile.open( ConfigSynthetic::InputfileOriSeeds.c_str(), ifstream::in );
	if ( txtfile.is_open() == true ) {
		size_t i = 0;
		size_t headerskip = 6;
		while ( txtfile.good() == true && i < headerskip ) {
			//skip a header row
			getline( txtfile, txtline );
			i++;
		}
		//interpret x, y, z and phi1, Phi, phi2 and texid from remaining rows
		i = 0;
		while( txtfile.good() == true && i < static_cast<size_t>(ConfigSynthetic::NumberOfSeeds) ) {
			getline( txtfile, txtline );
			//split the line into its tokens using boost
			vector<string> tokens;
#ifdef UTILIZE_BOOST
				boost::split( tokens, txtline, boost::is_any_of(" \t")); //can handle multiple delimiter different than getline
#else
			string input{txtline};
			regex re("[\\s\t]+"); //" [\\|,:]");
			//sregex_token_iterator first{input.begin(), input.end(), re, -1};
			sregex_token_iterator it(input.begin(), input.end(), re, -1);
			sregex_token_iterator last; //the '-1' is what makes the regex split (-1 := what was not matched)
			for( ; it != last; it++) {
				cout << "regex __" << it->str() << "__" << "\n";
				tokens.push_back( it->str() );
			}
#endif
			if ( tokens.size() != 7 ) {
				cerr << "Parsing InputfileOriSeeds line " << 6+i << " found unexpected number of tokens" << "\n";
				txtfile.close();
				return false;
			}
			else {
				seeds.push_back( oriseeds( 	stod(tokens.at(0)),
											stod(tokens.at(1)),
											stod(tokens.at(2)),
											stod(tokens.at(3)),
											stod(tokens.at(4)),
											stod(tokens.at(5)),
											stod(tokens.at(6))  )  );
				cout << seeds.back().x << ";" << seeds.back().y << ";" << seeds.back().z << ";" <<
						seeds.back().e1 << ";" << seeds.back().e2 << seeds.back().e3 << ";" << seeds.back().msid << "\n";
			}
			i++;
		}

		txtfile.close();
	}
	else {
		cerr << "Unable to open InputfileOriSeeds!" << "\n";
		txtfile.close();
		return false;
	}

	double toc = omp_get_wtime();
	cout << "Parsing InputfileOriSeeds took " << (toc-tic) << " seconds" << "\n";
	return true;
}


bool syntheticHdl::rve_synthesize()
{
	//build fully periodic 3d Voronoi container
	//for each grain compute all neighboring Voronoi cells

	double tic = omp_get_wtime();

	//##MK::currently dimensions are not parsed from the InputfileOriSeeds!
	rve = aabb3d( 	0.0, ConfigSynthetic::RVEDimensions.ldx,
					0.0, ConfigSynthetic::RVEDimensions.ldy,
					0.0, ConfigSynthetic::RVEDimensions.ldz );
	p3i blocks = rve.blockpartitioning( static_cast<size_t>(ConfigSynthetic::NumberOfSeeds),
					ConfigSynthetic::TessellationPointsPerBlock );

	bool periodicbox = true;
	container con(	rve.xmi - EPSILON, rve.xmx + EPSILON,
					rve.ymi - EPSILON, rve.ymx + EPSILON,
					rve.zmi - EPSILON, rve.zmx + EPSILON,
					blocks.x, blocks.y, blocks.z,
					periodicbox, periodicbox, periodicbox, 1);

	long myseed = ConfigShared::RndDescrStatsPRNGSeed;
	mt19937 mydice_geo;
	mydice_geo.seed( myseed );
	mydice_geo.discard( ConfigShared::RndDescrStatsPRNGDiscard );

	mt19937 mydice_ori;
	mydice_ori.seed( myseed );
	mydice_ori.discard( ConfigShared::RndDescrStatsPRNGDiscard );

	//get uniform random numbers to thin out randomly point cloud
	uniform_real_distribution<pdt_real> unifrnd(ZERO, ONE);

	//put NumberOfGrains many spatially uncorrelatedly i.e. randomly placed points into tipgeometry.mybox and get Voronoi cells about them
	polycrystal = vector<grain>( static_cast<size_t>(ConfigSynthetic::NumberOfSeeds), grain() );

	if ( seeds.size() < 1 || seeds.size() != static_cast<size_t>(ConfigSynthetic::NumberOfSeeds) ) {
		cerr << "WARNING::We do not use the values from InputfileOriSeeds but instead generate new seeds and orientations!" << "\n";

		for ( int txid = 0; txid < ConfigSynthetic::NumberOfSeeds; txid++ ) {
			p3d gc = p3d( 	rve.xmi + unifrnd(mydice_geo)*rve.xsz,
							rve.ymi + unifrnd(mydice_geo)*rve.ysz,
							rve.zmi + unifrnd(mydice_geo)*rve.zsz     );
			polycrystal.at(txid).cellcenter = gc;
			polycrystal.at(txid).texid = txid;
			//MK::define a random unit quaternion and interpret it as a Bunge passive orientation unit matrix
			polycrystal.at(txid).ori = squat( unifrnd(mydice_ori), unifrnd(mydice_ori), unifrnd(mydice_ori) );
			polycrystal.at(txid).cellvolume = ZERO;

			//represent grain as a Voronoi cell in the container
			con.put( txid, gc.x, gc.y, gc.z );

			/*cout << "q = " << q << endl;
							t3x3 local_ori = q.qu2om();
			cout << "localori = " << local_ori << endl;
			cout << "det(loc) = " << local_ori.det() << endl;*/
		}
	}
	else {
		cout << "Mapping damask ori.seeds on RVE domain..." << "\n";
		vector<oriseeds>::iterator it = seeds.begin();
		for ( int txid = 0; txid < ConfigSynthetic::NumberOfSeeds; txid++, it++) {
			int msid = static_cast<int>(it->msid); //this will be Fortran indexing
			if ( (msid-1) != txid ) { //test Fortran- to C-style against C-style indices
				cerr << "Interpreting OriSeeds line " << txid << " msid is different from txid!" << "\n"; return false;
			}
			if ( it->x < rve.xmi || it->x > rve.xmx ||
					it->y < rve.ymi || it->y > rve.ymx ||
						it->z < rve.zmi || it->z > rve.zmx ) {
				cerr << "Interpreting OriSeeds line " << txid << " x,y,z is out of rve!" << "\n"; return false;
			}
			bunge e_in = bunge( DEGREE2RADIANT(it->e1), DEGREE2RADIANT(it->e2), DEGREE2RADIANT(it->e3) );
			squat q_in = e_in.eu2qu();
			bunge e_out = q_in.qu2eu();
			squat q_out = e_out.eu2qu();
			pair<bool,squat> comp = disoriquaternion_cubic_cubic( q_in, q_out ); //##MK::only for cubic-cubic!
			if ( comp.first == false ) {
				cerr << "Interpreting OriSeeds line " << txid << " unable to compute disorientation!" << "\n"; return false;
			}
			else {
				pdt_real theta = 2.0*acos(comp.second.q0);
cout << "txid/disori.q0/theta " << txid << "\t\t" << comp.second.q0 << "\t\t" << theta << "\n";
				//if ( RADIANT2DEGREE(theta) > 0.5 ) {
				//cerr << "Interpreting OriSeeds line " << txid << " bunge euler angle incorrectly back-transformed!" << "\n"; return false;
				//}
			}

			p3d gc = p3d( it->x, it->y, it->z );
			polycrystal.at(txid).cellcenter = gc;
			polycrystal.at(txid).texid = txid;
			//MK::define a random unit quaternion and interpret it as a Bunge passive orientation unit matrix
			polycrystal.at(txid).ori = q_in;
			polycrystal.at(txid).cellvolume = ZERO;

			//represent grain as a Voronoi cell in the container
			con.put( txid, gc.x, gc.y, gc.z );
		}
	}

	//get temporaries to store the geometry of the Voronoi cells
	voronoicell_neighbor c;
	c_loop_all cl(con);
	if (cl.start()) { //this is an incremental computing of the tessellation which holds at no point the entire tessellation
		do {
			if ( con.compute_cell(c, cl) == true ) {
				//0 placed in this current cell
				//1 discarded because not in Voronoi cell bounding box
				//2 discarded because not closest to cell
				//3 discarded because not in tip
				int clpid = cl.pid(); //gather information about the cell/grain, specifically its geometry and aabb3d
				//if ( clpid != 106 )
				//	continue;

				//compute the Voronoi cell geometry
				double x, y, z;	//center
				cl.pos(x, y, z);
				vector<int> neigh; //neighbor cells
				c.neighbors(neigh);

				polycrystal.at(clpid).nbors = neigh;

				for( auto kt = neigh.begin(); kt != neigh.end(); kt++ ) {
					if ( *kt > - 1) {
						continue;
					}
					else {
						cerr << "Grain " << clpid << " has wall contact with " << *kt << "\n";
					}
				}

				//##MK::BEGIN DEBUG
				//for( auto it = polycrystal.at(clpid).nbors.begin(); it != polycrystal.at(clpid).nbors.end(); it++ ) {
				//	cout << "\t\t" << *it << "\n";
				//}
				//##MK::END DEBUG

				/*
				vector<int> fvert; //vertex indices
				c.face_vertices(fvert);
				vector<double> verts; //vertex coordinate values, not coordinate triplets!
				c.vertices(x, y, z, verts);

				//see documentation in VoroXX.cpp cell store heavydata
				map<int,int> old2new;
				vector<int> fvert_reindexed;
				vector<p3d> vtriplets_unique;

				//get number of unique float triplets
				//http://math.lbl.gov/voro++/examples/polygons/
				int ii = 0; int j = 0;
				for( size_t i = 0; i < neigh.size(); i++ ) { //O(N) processing
					for( int k = 0; k < fvert[j]; k++) { //generating 3d points with implicit indices 0, 1, 2, ....
						int l = 3*fvert[j+k+1];
						int implicitkey = l + (l+1)*1024 + (l+2)*1024*1024; //##MK::
						auto it = old2new.find( implicitkey );
						if ( it != old2new.end() ) { //integer triplet does exists already so reuse
							fvert_reindexed.push_back( it->second );
						}
						else { //integer triplet does not yet exist so create
							old2new.insert( make_pair( implicitkey, ii ) );
							fvert_reindexed.push_back( ii );
							vtriplets_unique.push_back( p3d(verts[l], verts[l+1], verts[l+2]) );
							ii++;
						}
					}
					j += fvert[j] + 1;
				}

				//pass heavy data to buffer
				ii = 0; j = 0;
				for( size_t i = 0; i < neigh.size(); i++ ) {
					tess.io_topo.push_back( static_cast<unsigned int>(3) ); //XDMF keyword to visualize an n-polygon
					tess.io_topo.push_back( static_cast<unsigned int>(fvert[j]) ); //how many edges on the polygon? promotion uint32 to size_t no problem
					for( int k = 0; k < fvert[j]; k++, ii++ ) {
						tess.io_topo.push_back( static_cast<unsigned int>(fvert_reindexed.at(ii)) );
					}
					j += fvert[j] + 1;
					tess.io_halo.push_back( clpid );
				}

				for( auto it = vtriplets_unique.begin(); it != vtriplets_unique.end(); it++ ) {
					tess.io_geom.push_back( it->x );
					tess.io_geom.push_back( it->y );
					tess.io_geom.push_back( it->z );
				}

				tess.io_info.push_back( voro_io_info(
						static_cast<size_t>(clpid), neigh.size(),
						fvert_reindexed.size() + 2*neigh.size(),
						vtriplets_unique.size()) ); //for ngeom report how many triplets not IDs!
				*/

				polycrystal.at(clpid).cellvolume = c.volume();

				/*
				//ion survived all pruning tests, so is inside cbox now its worth to do the more costly test
				apt_real DistTestSQR = F32MX;
				int clpid_ap_isclosest = INT32MI;
				int jjj = 0;
				//improve performance here
				for( auto iit = polycrystal.grains.begin(); iit != polycrystal.grains.end(); iit++, jjj++ ) {
					apt_real distsqr = SQR(iit->cellcenter.x-ap.x)+SQR(iit->cellcenter.y-ap.y)+SQR(iit->cellcenter.z-ap.z);
					if ( distsqr > DistTestSQR )
						continue;
					else {
						DistTestSQR = distsqr;
						clpid_ap_isclosest = jjj;
					}
				}
				*/

cout << "Grain " << clpid << " was constructed successfully" << "\n";
			} //done synthezising all grains of the rve
			else { //reporting an unconstructable Voronoi cell
cerr << "A grain was inconstrucible" << "\n";
			}
		} while (cl.inc());
	} //done with processing the Voronoi tessellation

	double toc = omp_get_wtime();
	cout << "Generate Poisson-Voronoi tessellation " << (toc-tic) << " seconds" << "\n";
	//memsnapshot mm = synthetic_tictoc.get_memoryconsumption();
	//synthetic_tictoc.prof_elpsdtime_and_mem( "GeneratePXMMMTip", APT_XX, APT_IS_PAR, mm, tic, toc);

cout << "RVE definition took " << (toc-tic) << " seconds" << "\n";

	return true;
}


bool syntheticHdl::rve_discretize()
{
	double tic = omp_get_wtime();

	geom.reserve( ConfigSynthetic::RVEDimensions.nxyz );
	pdt_real dx = ConfigSynthetic::RVEDimensions.ldx / static_cast<pdt_real>(ConfigSynthetic::RVEDimensions.nx);
	pdt_real dy = ConfigSynthetic::RVEDimensions.ldy / static_cast<pdt_real>(ConfigSynthetic::RVEDimensions.ny);
	pdt_real dz = ConfigSynthetic::RVEDimensions.ldz / static_cast<pdt_real>(ConfigSynthetic::RVEDimensions.nz);

	for( unsigned int z = 0; z < ConfigSynthetic::RVEDimensions.nz; z++ ) {
		pdt_real posz = 0.5*dz + z*dz;
		unsigned int zoff = z*ConfigSynthetic::RVEDimensions.nxy;
		for( unsigned int y = 0; y < ConfigSynthetic::RVEDimensions.ny; y++ ) {
			pdt_real posy = 0.5*dy + y*dy;
			unsigned yzoff = y*ConfigSynthetic::RVEDimensions.nx + zoff;
			for( unsigned int x = 0; x < ConfigSynthetic::RVEDimensions.nx; x++ ) {
				pdt_real posx = 0.5*dx + x*dx;
				unsigned int xyz = x + yzoff;
				geom.push_back( p3dm1( posx, posy, posz, xyz ) );
				//cout << posx << "\t\t" << posy << "\t\t" << posz << "\n";
			}
		}
	}

	double toc = omp_get_wtime();
	cout << "Discretize RVE " << (toc-tic) << " seconds" << "\n";

	return true;

}


bool syntheticHdl::rve_distances()
{
	double tic = omp_get_wtime();

	dist = vector<pdt_real>( geom.size(), FMX );

	int u = INT32MX;
	int v = INT32MX;
	int w = INT32MX;
	pdt_real Lx = ConfigSynthetic::RVEDimensions.ldx;
	pdt_real Ly = ConfigSynthetic::RVEDimensions.ldy;
	pdt_real Lz = ConfigSynthetic::RVEDimensions.ldz;
	vector<vector<p3dm1>*> rve27 = vector<vector<p3dm1>*>( polycrystal.size(), NULL );
	for( auto it = polycrystal.begin(); it != polycrystal.end(); it++ ) { //Moore neighborhood
		vector<p3dm1>* moore = NULL;
		moore = new vector<p3dm1>();
		if ( moore != NULL ) {
			u = -1; v = -1; w = -1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  0 ) );
			u = 0; v = -1; w = -1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  1 ) );
			u = +1; v = -1; w = -1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  2 ) );
			u = -1; v = 0; w = -1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  3 ) );
			u = 0; v = 0; w = -1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  4 ) );
			u = +1; v = 0; w = -1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  5 ) );
			u = -1; v = +1; w = -1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  6 ) );
			u = 0; v = +1; w = -1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  7 ) );
			u = +1; v = +1; w = -1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  8 ) );

			u = -1; v = -1; w = 0;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  9 ) );
			u = 0; v = -1; w = 0;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 10 ) );
			u = +1; v = -1; w = 0;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 11 ) );

			u = -1; v = 0; w = 0;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 12 ) );
			u = 0; v = 0; w = 0;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 13 ) );
			u = +1; v = 0; w = 0;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 14 ) );

			u = -1; v = +1; w = 0;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 15 ) );
			u = 0; v = +1; w = 0;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 16 ) );
			u = +1; v = +1; w = 0;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 17 ) );

			u = -1; v = -1; w = +1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 18 ) );
			u = 0; v = -1; w = +1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 19 ) );
			u = +1; v = -1; w = +1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 20 ) );
			u = -1; v = 0; w = +1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 21 ) );
			u = 0; v = 0; w = +1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 22 ) );
			u = +1; v = 0; w = +1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 23 ) );
			u = -1; v = +1; w = +1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 24 ) );
			u = 0; v = +1; w = +1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 25 ) );
			u = +1; v = +1; w = +1;
			moore->push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 26 ) );

			rve27.at(it->texid) = moore;
		}
		else {
			cerr << "Allocation of grain " << it->texid << " for Moore failed!" << "\n"; return false;
		}
	}
	//##MK::BEGIN DEBUG
	cout << "polycrystal " << polycrystal.size() << " rve27 " << rve27.size() << "\n";
	/*for( auto kt = rve27.begin(); kt != rve27.end(); kt++ ) {
		cout << kt->x << "\t\t" << kt->y << "\t\t" << kt->z << "\t\t" << kt->m << "\n";
	}*/
	//##MK::END DEBUG

	double toc = omp_get_wtime();
	cout << "Generate RVE27 " << (toc-tic) << " seconds" << "\n";
	tic = omp_get_wtime();

	#pragma omp parallel
	{
		vector<distifo> myres;
		vector<size_t> myfail;
		vector<pair<size_t,pdt_real>> myexcp;
		vector<pair<unsigned int, unsigned int>> mmpp;
		vector<p3dm1> mynbfail;

		#pragma omp for schedule(dynamic,1) nowait
		for( auto it = geom.begin(); it != geom.end(); it++) {
			//first get the closest grain
			pdt_real DistTestSQR = FMX;
			size_t j1 = SIZETMX;
			size_t j2 = SIZETMX;
			p3d here = p3d( it->x, it->y, it->z );
			for( size_t jt = 0; jt < rve27.size(); jt++ ) {
				for( auto jjt = rve27.at(jt)->begin(); jjt != rve27.at(jt)->end(); jjt++ ) {
					//we use the RVE27 to find matching closest cell center on opposite sides of the RVE domain
					pdt_real distsqr = SQR(jjt->x-here.x)+SQR(jjt->y-here.y)+SQR(jjt->z-here.z);
					if ( distsqr > DistTestSQR ) {
						continue;
					}
					else {
						DistTestSQR = distsqr;
						j1 = jt;
						j2 = jjt - rve27.at(jt)->begin();
					}
				}
			}
			if ( j1 != SIZETMX && j2 != SIZETMX ) {
				//store the cell (clpid) grain/texid for this voxel/matpoint
				unsigned int clpid = rve27.at(j1)->at(j2).m;
				it->pad = clpid;

				//we dont need to test against all cell positions and their Moore images
				//it suffices to inspect the neighbors of clpid and pick for each neighbor that specific image which is closest to the cell center
				//compute distance to cell boundary of cell rve27.at(j).m
				p3dm1 cell = rve27.at(j1)->at(j2); //a particular image
				vector<p3dm1> nbifo;
				for( auto iit =  polycrystal.at(clpid).nbors.begin(); iit != polycrystal.at(clpid).nbors.end(); iit++ ) { //neighbors does not include myself
					if ( *iit > -1 ) { //boundary side -1, -6
						//of all images for that neighbor find the one closest to cell
						pdt_real sqrd = FMX;
						p3dm1 cand = p3dm1(ZERO, ZERO, ZERO, UINT32MX, UINT32MX );
						unsigned int nbid = static_cast<unsigned int>(*iit);
						for( auto kt = rve27.at(nbid)->begin(); kt != rve27.at(nbid)->end(); kt++ ) {
							if ( (cell.m == kt->m && cell.pad == kt->pad) == false ) {
								pdt_real d = SQR(kt->x-cell.x)+SQR(kt->y-cell.y)+SQR(kt->z-cell.z);
								if ( d >= sqrd ) {
									continue;
								}
								else {
									sqrd = d;
									cand = p3dm1( kt->x, kt->y, kt->z, kt->m, kt->pad );
								}
							}
						}
						if ( cand.m != UINT32MX ) {
							nbifo.push_back( cand );
						}
						else {
							mynbfail.push_back( cand );
						}
					}
				}

				//we have Voronoi cells so the shortest distance is the projected distance between the point here and the bisector of clpid and neighboring cell
				pdt_real finaldist = FMX;
				size_t jj = SIZETMX;
				//evaluate bisector plane configuration in local collection of Voronoi cell seed point images
				for( auto nbt = nbifo.begin(); nbt != nbifo.end(); nbt++ ) {
					p3d there = p3d( nbt->x, nbt->y, nbt->z );
					p3d there_cell = p3d( there.x - cell.x, there.y - cell.y, there.z - cell.z ); //pointing from cell (center) to there
					pdt_real len_tc = sqrt(SQR(there_cell.x)+SQR(there_cell.y)+SQR(there_cell.z));
					//b^
					p3d ounrm = p3d( there_cell.x / len_tc, there_cell.y / len_tc, there_cell.z / len_tc );

					//pointing from cell (center) to here
					p3d here_cell = p3d( here.x - cell.x, here.y - cell.y, here.z - cell.z );

					//vector projection here_cell on ournm, i.e. normalized there_cell
					//a1 = a*b/||b||
					pdt_real discriminator = dot( here_cell, there_cell ) / len_tc;

					//normalized here and there to cell project here on there
					if ( discriminator >= ZERO ) { //we are in the half-space towards there
						//point bisecting vector there_cell in half
						//p3d mid = p3d( cell.x + 0.5*len_tc*ounrm.x, cell.y + 0.5*len_tc*ounrm.y, cell.z + 0.5*len_tc*ounrm.z );
						//a1 = ||a1||b^
						//p3d proj_cell = p3d( cell.x + discriminator*ounrm.x, cell.y + discriminator*ounrm.y, cell.z + discriminator*ounrm.z );
						if ( discriminator <= 0.5*len_tc && discriminator >= 0.0 ) { //proj is located on ray there_cell between position cell and position mid
							pdt_real currdist = 0.5*len_tc - discriminator;
							if ( currdist >= finaldist ) {
								continue;
							}
							else {
								finaldist = currdist;
								jj = nbt - nbifo.begin();
							}
						}
						else { //should not occur! if this happens clear sign that there is a logical flaw in the approach to get distance to interface
							//is expected to work only for convex non-degenerated polyhedra, like Poisson-Voronoi cells studied here...
							myexcp.push_back( pair<size_t,pdt_real>(jj, discriminator) );
						}
					}
					else { //we are in the opposite half-space
						continue;
					}
				} //all possible non-self bisecting planes analyzed
				if ( jj != SIZETMX ) {
					myres.push_back( distifo( finaldist, it - geom.begin() ));
				}
			}
			else {
				myfail.push_back( it - geom.begin() );
			}
			if ( ( it - geom.begin() ) % 10000 == 0 ) {
				#pragma omp critical
				{
					cout << "Thread " << omp_get_thread_num() << " passed " << it - geom.begin() << "\n";
				}
			}
		} //next voxel

		#pragma omp critical
		{
			int mt = omp_get_thread_num();
			cout << "Thread " << mt << " myres " << myres.size() << "\n";
			for( auto jt = myres.begin(); jt != myres.end(); jt++ ) {
				dist.at(jt->xyz) = jt->d;
				//cout << jt->xyz << "\t\t" << jt->d << "\n";
			}

			//##MK::BEGIN DEBUG
			if ( mynbfail.size() > 0 ) {
				cerr  << "Thread " << mt << " mynbfail " << mynbfail.size() << "\n";
			}
			if ( myfail.size() > 0 ) {
				cerr  << "Thread " << mt << " myfailures " << myfail.size() << "\n";
			}
			//for( auto kt = myfail.begin(); kt != myfail.end(); kt++ ) {
			//	cerr << *kt << "\n";
			//}
			//cout << "Thread " << mt << " mmpp " << mmpp.size() << "\n";
			//for( auto kt = mmpp.begin(); kt != mmpp.end(); kt++ ) {
			//	cerr << kt->first << "\t\t" << kt->second << "\n";
			//}
			if ( myexcp.size() > 0 ) {
				cerr << "Thread " << mt << " myexcp " << myexcp.size() << "\n";
			}
			//for( auto kt = myexcp.begin(); kt != myexcp.end(); kt++ ) {
			//	cerr << kt->first << "\t\t" << kt->second << "\n";
			//}
			//##MK::END DEBUG
		}
	}

	for( size_t i = 0; i < rve27.size(); i++ ) {
		if ( rve27.at(i) != NULL ) {
			delete rve27.at(i);
			rve27.at(i) = NULL;
		}
	}

	toc = omp_get_wtime();
	cout << "Distancing for all voxel center " << (toc-tic) << " seconds" << "\n";
	return true;
}

/*
bool syntheticHdl::rve_distances1()
{
	double tic = omp_get_wtime();

	dist = vector<pdt_real>( geom.size(), FMX );

	int u = INT32MX;
	int v = INT32MX;
	int w = INT32MX;
	pdt_real Lx = ConfigSynthetic::RVEDimensions.ldx;
	pdt_real Ly = ConfigSynthetic::RVEDimensions.ldy;
	pdt_real Lz = ConfigSynthetic::RVEDimensions.ldz;
	rve27.reserve( 27*polycrystal.size() );
	for( auto it = polycrystal.begin(); it != polycrystal.end(); it++ ) { //Moore neighborhood
		u = -1; v = -1; w = -1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  0 ) );
		u = 0; v = -1; w = -1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  1 ) );
		u = +1; v = -1; w = -1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  2 ) );
		u = -1; v = 0; w = -1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  3 ) );
		u = 0; v = 0; w = -1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  4 ) );
		u = +1; v = 0; w = -1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  5 ) );
		u = -1; v = +1; w = -1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  6 ) );
		u = 0; v = +1; w = -1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  7 ) );
		u = +1; v = +1; w = -1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  8 ) );

		u = -1; v = -1; w = 0;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid,  9 ) );
		u = 0; v = -1; w = 0;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 10 ) );
		u = +1; v = -1; w = 0;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 11 ) );

		u = -1; v = 0; w = 0;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 12 ) );
		u = 0; v = 0; w = 0;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 13 ) );
		u = +1; v = 0; w = 0;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 14 ) );

		u = -1; v = +1; w = 0;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 15 ) );
		u = 0; v = +1; w = 0;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 16 ) );
		u = +1; v = +1; w = 0;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 17 ) );

		u = -1; v = -1; w = +1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 18 ) );
		u = 0; v = -1; w = +1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 19 ) );
		u = +1; v = -1; w = +1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 20 ) );
		u = -1; v = 0; w = +1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 21 ) );
		u = 0; v = 0; w = +1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 22 ) );
		u = +1; v = 0; w = +1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 23 ) );
		u = -1; v = +1; w = +1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 24 ) );
		u = 0; v = +1; w = +1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 25 ) );
		u = +1; v = +1; w = +1;
		rve27.push_back( p3dm1( static_cast<pdt_real>(u)*Lx + it->cellcenter.x, static_cast<pdt_real>(v)*Ly + it->cellcenter.y, static_cast<pdt_real>(w)*Lz + it->cellcenter.z, it->texid, 26 ) );
	}
	//##MK::BEGIN DEBUG
	cout << "polycrystal " << polycrystal.size() << " rve27 " << rve27.size() << "\n";
	//for( auto kt = rve27.begin(); kt != rve27.end(); kt++ ) {
	//	cout << kt->x << "\t\t" << kt->y << "\t\t" << kt->z << "\t\t" << kt->m << "\n";
	//}
	//##MK::END DEBUG

	double toc = omp_get_wtime();
	cout << "Generate RVE27 " << (toc-tic) << " seconds" << "\n";
	tic = omp_get_wtime();

	#pragma omp parallel
	{
		vector<distifo> myres;
		vector<size_t> myfail;
		vector<pair<size_t,pdt_real>> myexcp;
		vector<pair<unsigned int, unsigned int>> mmpp;

		#pragma omp for schedule(dynamic,1) nowait
		for( auto it = geom.begin(); it != geom.end(); it++) {
			//get closest grain
			pdt_real DistTestSQR = FMX;
			size_t j = SIZETMX;
			p3d here = p3d( it->x, it->y, it->z );
			for( auto jt = rve27.begin(); jt != rve27.end(); jt++ ) {
				//we use the RVE27 to find matching closest cell center on opposite sides of the RVE domain
				pdt_real distsqr = SQR(jt->x-here.x)+SQR(jt->y-here.y)+SQR(jt->z-here.z);
				if ( distsqr > DistTestSQR )
					continue;
				else {
					DistTestSQR = distsqr;
					j = jt - rve27.begin();
				}
			}
			if ( j != SIZETMX ) {
				//store the cell (clpid) grain/texid for this point
				unsigned int clpid = rve27.at(j).m;
				it->pad = clpid;
				//compute distance to cell boundary of cell rve27.at(j).m
				p3dm1 cell = rve27.at(j); //clpid = m
				//we have Voronoi cells so the shortest distance is the projected distance between the point here and the bisector of clpid and neighboring cell
				pdt_real finaldist = FMX;
				size_t jj = SIZETMX;
				//get neighboring Voronoi cells for grain/cell at(j).m
				vector<unsigned int> nb;
				for( auto iit =  polycrystal.at(clpid).nbors.begin(); iit != polycrystal.at(clpid).nbors.end(); iit++ ) {
					if ( *iit > -1 ) { //boundary side -1, -6
						nb.push_back( static_cast<unsigned int>(*iit) );
					}
				}
				for( auto jt = rve27.begin(); jt != rve27.end(); jt++ ) {
					bool consider = false;
					for( auto jjt = nb.begin(); jjt != nb.end(); jjt++ ) {
						if ( *jjt != jt->m ) {
							continue;
						}
						else {
							consider = true;
							break;
						}
					}
					if ( consider == false ) { //skip all non-neighbors and other images cells
						continue;
					}
					//only check against neighbors
					if ( jt->m != cell.m && jt->pad != cell.pad ) { //no self-intersection with cell, signature for such self intersection is m and pad
						p3d there = p3d( jt->x, jt->y, jt->z );
						p3d there_cell = p3d( there.x - cell.x, there.y - cell.y, there.z - cell.z ); //pointing from cell (center) to there
						pdt_real len_tc = sqrt(SQR(there_cell.x)+SQR(there_cell.y)+SQR(there_cell.z));
						//b^
						p3d ounrm = p3d( there_cell.x / len_tc, there_cell.y / len_tc, there_cell.z / len_tc );

						//pointing from cell (center) to here
						p3d here_cell = p3d( here.x - cell.x, here.y - cell.y, here.z - cell.z );

						//vector projection here_cell on ournm, i.e. normalized there_cell
						//a1 = a*b/||b||
						pdt_real discriminator = dot( here_cell, there_cell ) / len_tc;

						//normalized here and there to cell project here on there
						if ( discriminator >= ZERO ) { //we are in the half-space towards there
							//point bisecting vector there_cell in half
							//p3d mid = p3d( cell.x + 0.5*len_tc*ounrm.x, cell.y + 0.5*len_tc*ounrm.y, cell.z + 0.5*len_tc*ounrm.z );
							//a1 = ||a1||b^
							//p3d proj_cell = p3d( cell.x + discriminator*ounrm.x, cell.y + discriminator*ounrm.y, cell.z + discriminator*ounrm.z );
							if ( discriminator <= 0.5*len_tc && discriminator >= 0.0 ) { //proj is located on ray there_cell between position cell and position mid
								pdt_real currdist = 0.5*len_tc - discriminator;
								if ( currdist >= finaldist ) {
									continue;
								}
								else {
									finaldist = currdist;
									jj = jt - rve27.begin();
								}
							}
							else { //should not occur! if this happens clear sign that there is a logical flaw in the approach to get distance to interface
								//is expected to work only for convex non-degenerated polyhedra, like Poisson-Voronoi cells studied here...
								myexcp.push_back( pair<size_t,pdt_real>(jt-rve27.begin(), discriminator) );
							}
						}
						else { //we are in the opposite half-space
							continue;
						}
					}
					//else {
					//	mmpp.push_back( pair<unsigned int,unsigned int>( jt->m, jt->pad ) );
					//}
				} //all possible non-self bisecting planes analyzed
				if ( jj != SIZETMX ) {
					myres.push_back( distifo( finaldist, it - geom.begin() ));
				}
			}
			else {
				myfail.push_back( it - geom.begin() );
			}
			if ( ( it - geom.begin() ) % 10000 == 0 ) {
				#pragma omp critical
				{
					cout << "Thread " << omp_get_thread_num() << " passed " << it - geom.begin() << "\n";
				}
			}
		} //next voxel

		#pragma omp critical
		{
			int mt = omp_get_thread_num();
			cout << "Thread " << mt << " myres " << myres.size() << "\n";
			for( auto jt = myres.begin(); jt != myres.end(); jt++ ) {
				dist.at(jt->xyz) = jt->d;
				//cout << jt->xyz << "\t\t" << jt->d << "\n";
			}

			//##MK::BEGIN DEBUG
			if ( myfail.size() > 0 ) {
				cerr  << "Thread " << mt << " myfailures " << myfail.size() << "\n";
			}
			//for( auto kt = myfail.begin(); kt != myfail.end(); kt++ ) {
			//	cerr << *kt << "\n";
			//}
			//cout << "Thread " << mt << " mmpp " << mmpp.size() << "\n";
			//for( auto kt = mmpp.begin(); kt != mmpp.end(); kt++ ) {
			//	cerr << kt->first << "\t\t" << kt->second << "\n";
			//}
			if ( myexcp.size() > 0 ) {
				cerr << "Thread " << mt << " myexcp " << myexcp.size() << "\n";
			}
			//for( auto kt = myexcp.begin(); kt != myexcp.end(); kt++ ) {
			//	cerr << kt->first << "\t\t" << kt->second << "\n";
			//}
			//##MK::END DEBUG
		}
	}

	toc = omp_get_wtime();
	cout << "Distancing for all voxel center " << (toc-tic) << " seconds" << "\n";
	return true;
}
*/


bool syntheticHdl::init_target_file()
{
	//##MK::generate group hierarchy of an open source IFES APTTC APTH5 HDF5 file
	string h5fn_out = "DAMASKPDT.Synthetic.Results.SimID." + to_string(ConfigShared::SimID) + ".h5";
cout << "Initializing target file " << h5fn_out << "\n";

	if ( debugh5Hdl.create_synthetic_h5( h5fn_out ) == WRAPPED_HDF5_SUCCESS ) {
		return true;
	}
	return false;
}


void syntheticHdl::write_damask_geom()
{
	//MK::generate a DAMASK *.geom startup file
	double tic = omp_get_wtime();

	if ( geom.size() != ConfigSynthetic::RVEDimensions.nxyz ) {
		cerr << "geom.size() != ConfigSynthetic::RVEDimensions.nxyz!" << "\n"; return;
	}

	string fn = to_string(polycrystal.size()) + "g"
					+ to_string(ConfigSynthetic::RVEDimensions.nx) + "x"
					+ to_string(ConfigSynthetic::RVEDimensions.nx) + "x"
					+ to_string(ConfigSynthetic::RVEDimensions.nx) + ".geom";

	ofstream csv;
	csv.open( fn.c_str(), ofstream::trunc );
	if ( csv.is_open() == true ) {
		size_t nheader = 1 + 3 + 1 + 1 + 1 + 3*polycrystal.size() + 1 + 2*polycrystal.size(); //comment, grid, size, origin, homo, microstructures, microstructure-keyword, triplet of [Grain] crystallite and constituents, texture-keyword, pair of [Grain] (gauss)
		csv << to_string(nheader) << " header" << "\n";
		csv << "geom_fromVoronoiTessellation v2.0.1-992-g20d8133 damaskpdt-synthetic" << "\n";
		csv << "grid	a " << to_string(ConfigSynthetic::RVEDimensions.nx) <<
				"	b " << to_string(ConfigSynthetic::RVEDimensions.ny) <<
				"	c " << to_string(ConfigSynthetic::RVEDimensions.nz) << "\n";
		csv << "size	x " << to_string(ConfigSynthetic::RVEDimensions.ldx) <<
				"	y " << to_string(ConfigSynthetic::RVEDimensions.ldy) <<
				"	z " << to_string(ConfigSynthetic::RVEDimensions.ldz) << "\n";
		csv << "origin	x 0.0	y 0.0	z 0.0" << "\n";
		csv << "homogenization	1" << "\n";
		csv << "microstructures	" << to_string(polycrystal.size()) << "\n";
		csv << "<microstructure>" << "\n";
		for( auto it = polycrystal.begin(); it != polycrystal.end(); it++ ) {
			unsigned int fortranid = it->texid + 1;
			string threedigit = "";
			if ( it->texid > 99 ) {
				threedigit = to_string(fortranid);
			}
			else if ( it->texid > 9 ) {
				threedigit = "0" + to_string(fortranid);
			}
			else {
				threedigit = "00" + to_string(fortranid);
			}
			csv << "[Grain" << threedigit << "]" << "\n";
			csv << "crystallite 1" << "\n";
			csv << "(constituent)	phase 1	texture   " << fortranid << "	fraction 1.0" << "\n"; //MK::polycrystal is already ordered
		}
		csv << "<texture>" << "\n";
		for( auto it = polycrystal.begin(); it != polycrystal.end(); it++ ) {
			bunge b = it->ori.qu2eu();
			unsigned int fortranid = it->texid + 1;
			string threedigit = "";
			if ( it->texid > 99 ) {
				threedigit = to_string(fortranid);
			}
			else if ( it->texid > 9 ) {
				threedigit = "0" + to_string(fortranid);
			}
			else {
				threedigit = "00" + to_string(fortranid);
			}
			csv << "[Grain" << threedigit << "]" << "\n";
			csv << "(gauss)	phi1 " << RADIANT2DEGREE(b.phi1) << " Phi " <<
						RADIANT2DEGREE(b.Phi) << " phi2 " <<
							RADIANT2DEGREE(b.phi2) << "	scatter 0.0	fraction 1.0" << "\n";
		}
		csv << " ";
		for( unsigned int z = 0; z < ConfigSynthetic::RVEDimensions.nz; z++ ) {
			unsigned int zoff = z*ConfigSynthetic::RVEDimensions.nxy;
			for( unsigned int y = 0; y < ConfigSynthetic::RVEDimensions.ny; y++ ) {
				unsigned yzoff = y*ConfigSynthetic::RVEDimensions.nx + zoff;
				for( unsigned int x = 0; x < ConfigSynthetic::RVEDimensions.nx; x++ ) {
					unsigned int xyz = x + yzoff;
					csv << "  " << to_string(geom.at(xyz).pad + 1); //start with " " instead of "  ", go from C-style to Fortran-style indexing
				}
				csv << "\n";
			}
		}
		csv.flush();
		csv.close();
	}

	double toc = omp_get_wtime();
	cout << fn << " I/O in " << (toc-tic) << " seconds" << "\n";
}


void syntheticHdl::write_distances_to_h5()
{
	double tic = MPI_Wtime();

	int status = WRAPPED_HDF5_SUCCESS;
	h5iometa ifo = h5iometa();
	h5offsets offs = h5offsets();
	//write dist in-place

	//distances
	string dsnm = PDT_SYNTH_VOLRECON_RES_DIST;
	ifo = h5iometa( PDT_SYNTH_VOLRECON_RES_DIST, dist.size()/PDT_SYNTH_VOLRECON_RES_DIST_NCMAX,
			PDT_SYNTH_VOLRECON_RES_DIST_NCMAX );
	status = debugh5Hdl.create_contiguous_matrix_f64le( ifo );
	if ( status == WRAPPED_HDF5_SUCCESS ) {
		cout << "PDT_SYNTH_VOLRECON_RES_DIST create " << status << "\n";
		offs = h5offsets( 0, dist.size()/PDT_SYNTH_VOLRECON_RES_DIST_NCMAX, 0, PDT_SYNTH_VOLRECON_RES_DIST_NCMAX,
				dist.size()/PDT_SYNTH_VOLRECON_RES_DIST_NCMAX, PDT_SYNTH_VOLRECON_RES_DIST_NCMAX);
		status = debugh5Hdl.write_contiguous_matrix_f64le_hyperslab( ifo, offs, dist );
		if ( status != WRAPPED_HDF5_SUCCESS ) {
			cerr << "PDT_SYNTH_VOLRECON_RES_DIST write failed! " << status << "\n"; return;
		}
	}
	else {
		cerr << "PDT_SYNTH_VOLRECON_RES_DIST create failed! " << status << "\n"; return;
	}

	//texture ID
	vector<unsigned int> u32;
	u32.reserve( geom.size() );
	for( auto it = geom.begin(); it != geom.end(); it++ ) {
		u32.push_back( it->pad + 1 );
	}
	dsnm = PDT_SYNTH_VOLRECON_RES_TEXID;
	ifo = h5iometa( PDT_SYNTH_VOLRECON_RES_TEXID, u32.size()/PDT_SYNTH_VOLRECON_RES_TEXID_NCMAX,
			PDT_SYNTH_VOLRECON_RES_TEXID_NCMAX );
	status = debugh5Hdl.create_contiguous_matrix_u32le( ifo );
	if ( status == WRAPPED_HDF5_SUCCESS ) {
		cout << "PDT_SYNTH_VOLRECON_RES_TEXID create " << status << "\n";
		offs = h5offsets( 0, u32.size()/PDT_SYNTH_VOLRECON_RES_TEXID_NCMAX, 0, PDT_SYNTH_VOLRECON_RES_TEXID_NCMAX,
				u32.size()/PDT_SYNTH_VOLRECON_RES_TEXID_NCMAX, PDT_SYNTH_VOLRECON_RES_TEXID_NCMAX);
		status = debugh5Hdl.write_contiguous_matrix_u32le_hyperslab( ifo, offs, u32 );
		if ( status != WRAPPED_HDF5_SUCCESS ) {
			cerr << "PDT_SYNTH_VOLRECON_RES_TEXID write failed! " << status << "\n"; return;
		}
	}
	else {
		cerr << "PDT_SYNTH_VOLRECON_RES_TEXID create failed! " << status << "\n"; return;
	}
	u32 = vector<unsigned int>();

	double toc = MPI_Wtime();
	cout << "H5 I/O " << (toc-tic) << " seconds" << "\n";
}


void syntheticHdl::write_grains_to_h5()
{
	int status = WRAPPED_HDF5_SUCCESS;
	h5iometa ifo = h5iometa();
	h5offsets offs = h5offsets();
	vector<double> f64;
	vector<unsigned int> u32;

	//report grainsAggregate
	if ( polycrystal.size() > 0 ) {
		//grain orientation
		f64.reserve( polycrystal.size()*PDT_SYNTH_VOLRECON_META_GRNS_ORI_NCMAX );
		for( auto it = polycrystal.begin(); it != polycrystal.end(); it++ ) {
			f64.push_back( it->ori.q0 );
			f64.push_back( it->ori.q1 );
			f64.push_back( it->ori.q2 );
			f64.push_back( it->ori.q3 );
		}
		ifo = h5iometa( PDT_SYNTH_VOLRECON_META_GRNS_ORI, f64.size()/PDT_SYNTH_VOLRECON_META_GRNS_ORI_NCMAX,
				PDT_SYNTH_VOLRECON_META_GRNS_ORI_NCMAX );
		status = debugh5Hdl.create_contiguous_matrix_f64le( ifo );
		if ( status == WRAPPED_HDF5_SUCCESS ) {
			cout << "PDT_SYNTH_VOLRECON_META_GRNS_ORI create " << status << "\n";
			offs = h5offsets( 0, f64.size()/PDT_SYNTH_VOLRECON_META_GRNS_ORI_NCMAX, 0, PDT_SYNTH_VOLRECON_META_GRNS_ORI_NCMAX,
					f64.size()/PDT_SYNTH_VOLRECON_META_GRNS_ORI_NCMAX, PDT_SYNTH_VOLRECON_META_GRNS_ORI_NCMAX);
			status = debugh5Hdl.write_contiguous_matrix_f64le_hyperslab( ifo, offs, f64 );
			if ( status == WRAPPED_HDF5_SUCCESS ) {
				cout << "PDT_SYNTH_VOLRECON_META_GRNS_ID write " << status << "\n";
			}
			else {
				cerr << "PDT_SYNTH_VOLRECON_META_GRNS_ORI write failed! " << status << "\n"; return;
			}
		}
		else {
			cerr << "PDT_SYNTH_VOLRECON_META_GRNS_ORI create failed! " << status << "\n"; return;
		}
		f64 = vector<double>();

		//grain IDs
		u32.reserve( polycrystal.size()*PDT_SYNTH_VOLRECON_META_GRNS_ID_NCMAX );
		for( auto it = polycrystal.begin(); it != polycrystal.end(); it++ ) {
			u32.push_back( it->texid );
		}
		ifo = h5iometa( PDT_SYNTH_VOLRECON_META_GRNS_ID, u32.size()/PDT_SYNTH_VOLRECON_META_GRNS_ID_NCMAX, PDT_SYNTH_VOLRECON_META_GRNS_ID_NCMAX );
		status = debugh5Hdl.create_contiguous_matrix_u32le( ifo );
		if ( status == WRAPPED_HDF5_SUCCESS ) {
			cout << "PDT_SYNTH_VOLRECON_META_GRNS_ID create " << status << "\n";
			offs = h5offsets( 0, u32.size()/PDT_SYNTH_VOLRECON_META_GRNS_ID_NCMAX, 0, PDT_SYNTH_VOLRECON_META_GRNS_ID_NCMAX,
						u32.size()/PDT_SYNTH_VOLRECON_META_GRNS_ID_NCMAX, PDT_SYNTH_VOLRECON_META_GRNS_ID_NCMAX);
			status = debugh5Hdl.write_contiguous_matrix_u32le_hyperslab( ifo, offs, u32 );
			if ( status == WRAPPED_HDF5_SUCCESS ) {
				cout << "PDT_SYNTH_VOLRECON_META_GRNS_ID write " << status << "\n";
			}
			else {
				cerr << "PDT_SYNTH_VOLRECON_META_GRNS_ID write failed! " << status << "\n"; return;
			}
		}
		else {
			cerr << "PDT_SYNTH_VOLRECON_META_GRNS_ID create failed! " << status << "\n"; return;
		}
		u32 = vector<unsigned int>();

		//grain cellcenter position measured using voro++
		f64.reserve( polycrystal.size()*PDT_SYNTH_VOLRECON_META_GRNS_XYZ_NCMAX );
		for( auto it = polycrystal.begin(); it != polycrystal.end(); it++ ) {
			f64.push_back( it->cellcenter.x );
			f64.push_back( it->cellcenter.y );
			f64.push_back( it->cellcenter.z );
		}
		ifo = h5iometa( PDT_SYNTH_VOLRECON_META_GRNS_XYZ, f64.size()/PDT_SYNTH_VOLRECON_META_GRNS_XYZ_NCMAX, PDT_SYNTH_VOLRECON_META_GRNS_XYZ_NCMAX );
		status = debugh5Hdl.create_contiguous_matrix_f64le( ifo );
		if ( status == WRAPPED_HDF5_SUCCESS ) {
			cout << "PDT_SYNTH_VOLRECON_META_GRNS_XYZ create " << status << "\n";
			offs = h5offsets( 0, f64.size()/PDT_SYNTH_VOLRECON_META_GRNS_XYZ_NCMAX, 0, PDT_SYNTH_VOLRECON_META_GRNS_XYZ_NCMAX,
					f64.size()/PDT_SYNTH_VOLRECON_META_GRNS_XYZ_NCMAX, PDT_SYNTH_VOLRECON_META_GRNS_XYZ_NCMAX);
			status = debugh5Hdl.write_contiguous_matrix_f64le_hyperslab( ifo, offs, f64 );
			if ( status == WRAPPED_HDF5_SUCCESS ) {
				cout << "PDT_SYNTH_VOLRECON_META_GRNS_XYZ write " << status << "\n";
			}
			else {
				cerr << "PDT_SYNTH_VOLRECON_META_GRNS_XYZ write failed! " << status << "\n"; return;
			}
		}
		else {
			cerr << "PDT_SYNTH_VOLRECON_META_GRNS_XYZ create failed! " << status << "\n"; return;
		}
		f64 = vector<double>();

		//grain volume measured using voro++
		f64.reserve( polycrystal.size()*PDT_SYNTH_VOLRECON_META_GRNS_VOL_NCMAX );
		for( auto it = polycrystal.begin(); it != polycrystal.end(); it++ ) {
			f64.push_back( it->cellvolume );
		}
		ifo = h5iometa( PDT_SYNTH_VOLRECON_META_GRNS_VOL, f64.size()/PDT_SYNTH_VOLRECON_META_GRNS_VOL_NCMAX, PDT_SYNTH_VOLRECON_META_GRNS_VOL_NCMAX );
		status = debugh5Hdl.create_contiguous_matrix_f64le( ifo );
		if ( status == WRAPPED_HDF5_SUCCESS ) {
			cout << "PDT_SYNTH_VOLRECON_META_GRNS_VOL create " << status << "\n";
			offs = h5offsets( 0, f64.size()/PDT_SYNTH_VOLRECON_META_GRNS_VOL_NCMAX, 0, PDT_SYNTH_VOLRECON_META_GRNS_VOL_NCMAX,
					f64.size()/PDT_SYNTH_VOLRECON_META_GRNS_VOL_NCMAX, PDT_SYNTH_VOLRECON_META_GRNS_VOL_NCMAX);
			status = debugh5Hdl.write_contiguous_matrix_f64le_hyperslab( ifo, offs, f64 );
			if ( status == WRAPPED_HDF5_SUCCESS ) {
				cout << "PDT_SYNTH_VOLRECON_META_GRNS_VOL write " << status << "\n";
			}
			else {
				cerr << "PDT_SYNTH_VOLRECON_META_GRNS_VOL write failed! " << status << "\n"; return;
			}
		}
		else {
			cerr << "PDT_SYNTH_VOLRECON_META_GRNS_VOL create failed! " << status << "\n"; return;
		}
		f64 = vector<double>();
	}
}


/*
void syntheticHdl::rve_cells_to_h5()
{
	if ( ConfigSynthetic::SynthesizingMode == E_SYNTHESIS_DEVELOPMENT_PX ) {
		//report the Voronoi tessellation
		//first of all translate all local IDs into global IDs
		//##MK::relabeling of cell topology required because vertex indices are per cell
		size_t VertexOffset = 0;
		size_t CurrentCellID = 0;
		for( size_t i = 1; i < tess.io_topo.size();   ) { //first value tells XDMF topology typ index of first local cell ignore this value
			size_t CurrentCellNumberOfFaces = tess.io_info.at(CurrentCellID).nfacets;
			for( size_t f = 0; f < CurrentCellNumberOfFaces; f++ ) {
				size_t CurrentFacetNumberOfIndices = tess.io_topo.at(i);
				i++;
				for( size_t k = 0; k < CurrentFacetNumberOfIndices; k++ ) {
					tess.io_topo.at(i+k) = tess.io_topo.at(i+k) + VertexOffset;
				}
				i = i + CurrentFacetNumberOfIndices + 1; //skip updated values skip XDMF type key
			}
			//cout << "CurrentCellNumberOfFaces--->" << CurrentCellNumberOfFaces << "\t\t\t" << VertexOffset << endl;
			VertexOffset = VertexOffset + tess.io_info.at(CurrentCellID).ngeom;
			CurrentCellID++;
		}

		cout << "XDMF Voronoi cell topology" << "\n";
		size_t NumberOfElements = 0;
		for( auto it = tess.io_info.begin(); it != tess.io_info.end(); ++it ) {
			NumberOfElements += it->nfacets;
		}
		cout << "Number of geom. elements " << NumberOfElements << "\n";
		cout << "Number of topology values " << tess.io_topo.size() << "\n";
		cout << "Number of geometry values " << tess.io_geom.size() << "\n";
		cout << "Number of scalar cell attribute values " << tess.io_halo.size() << "\n";

		string xmlfn = "PARAPROBE.Synthetic.Results.SimID." + to_string(ConfigShared::SimID) + ".VoroTess.xdmf";
		debugxdmf.create_voronoicrystal_file( xmlfn, NumberOfElements, tess.io_topo.size()/1,
					tess.io_geom.size()/3, tess.io_halo.size()/1, debugh5Hdl.h5resultsfn);

		//hdf5 writing
		int status = WRAPPED_HDF5_SUCCESS;
		h5iometa ifo = h5iometa();
		h5offsets offs = h5offsets();

		string grpnm = PARAPROBE_SYNTH_VOLRECON_META_TESS;
		status = debugh5Hdl.create_group( grpnm );
		if ( status != WRAPPED_HDF5_SUCCESS ) {
			cerr << "PARAPROBE_SYNTH_VOLRECON_META_TESS group creation failed! " << status << "\n"; return;
		}

		//voronoi cell facet topology
		ifo = h5iometa( PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO, tess.io_topo.size()/PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO_NCMAX,
				PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO_NCMAX );
		status = debugh5Hdl.create_contiguous_matrix_u32le( ifo );
		if ( status != WRAPPED_HDF5_SUCCESS ) {
			cerr << "PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO create failed! " << status << "\n"; return;
		}
		cout << "PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO create " << status << "\n";
		offs = h5offsets( 0, tess.io_topo.size()/PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO_NCMAX,
				0, PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO_NCMAX,
				tess.io_topo.size()/PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO_NCMAX, PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO_NCMAX);
		status = debugh5Hdl.write_contiguous_matrix_u32le_hyperslab( ifo, offs, tess.io_topo );
		if ( status != WRAPPED_HDF5_SUCCESS ) {
			cerr << "PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO write failed! " << status << "\n"; return;
		}
		cout << "PARAPROBE_SYNTH_VOLRECON_META_TESS_TOPO write " << status << "\n";
		tess.io_topo = vector<unsigned int>();

		//voronoi cell facet edge vertices xyz
		ifo = h5iometa( PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ,
					tess.io_geom.size()/PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ_NCMAX,
						PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ_NCMAX );
		status = debugh5Hdl.create_contiguous_matrix_f32le( ifo );
		if ( status != WRAPPED_HDF5_SUCCESS ) {
			cerr << "PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ create failed! " << status << "\n"; return;
		}
		cout << "PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ create " << status << "\n";
		offs = h5offsets( 0, tess.io_geom.size()/PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ_NCMAX,
				0, PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ_NCMAX,
				tess.io_geom.size()/PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ_NCMAX, PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ_NCMAX);
		status = debugh5Hdl.write_contiguous_matrix_f32le_hyperslab( ifo, offs, tess.io_geom );
		if ( status != WRAPPED_HDF5_SUCCESS ) {
			cerr << "PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ write failed! " << status << "\n"; return;
		}
		cout << "PARAPROBE_SYNTH_VOLRECON_META_TESS_XYZ write " << status << "\n";
		tess.io_geom = vector<float>();

		//halo info
		ifo = h5iometa( PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO, tess.io_halo.size()/PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO_NCMAX,
						PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO_NCMAX );
		status = debugh5Hdl.create_contiguous_matrix_i32le( ifo );
		if ( status != WRAPPED_HDF5_SUCCESS ) {
			cerr << "PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO create failed! " << status << "\n"; return;
		}
		cout << "PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO create " << status << "\n";
		offs = h5offsets( 0, tess.io_halo.size()/PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO_NCMAX,
				0, PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO_NCMAX,
				tess.io_geom.size()/PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO_NCMAX, PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO_NCMAX);
		status = debugh5Hdl.write_contiguous_matrix_i32le_hyperslab( ifo, offs, tess.io_halo );
		if ( status != WRAPPED_HDF5_SUCCESS ) {
			cerr << "PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO write failed! " << status << "\n"; return;
		}
		cout << "PARAPROBE_SYNTH_VOLRECON_META_TESS_HALO write " << status << "\n";
		tess.io_halo = vector<int>();
	}
}
*/
