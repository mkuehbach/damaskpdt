//##MK::GPLV3

#ifndef __PDT_SYNTHETICHDF_H__
#define __PDT_SYNTHETICHDF_H__

//shared headers
#include "../../damaskpdt-utils/src/metadata/PDT_SyntheticMetadataDefsH5.h"
#include "../../damaskpdt-utils/src/PDT_XDMF.h"

//tool-specific headers
#include "CONFIG_Synthetic.h"

class synthetic_h5 : public h5Hdl
{
	//tool-specific sub-class of a HDF5 inheriting all methods of the base class h5Hdl
	//coordinating instance handling all (sequential) writing to HDF5 file wrapping HDF5 low-level C library calls

public:
	synthetic_h5();
	~synthetic_h5();

	int create_synthetic_h5( const string h5fn );

//private:
};

#endif
