//##MK::GPLV3

#include "PDT_TessellationHdl.h"

tessHdl::tessHdl()
{
	
}


tessHdl::~tessHdl()
{
	
}
