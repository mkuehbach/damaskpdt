//##MK::GPLV3

#ifndef __PARAPROBE_SYNTHETIC_VOROXXINTERFACE_H__
#define __PARAPROBE_SYNTHETIC_VOROXXINTERFACE_H__

#include "PARAPROBE_SyntheticTicToc.h"

#include "thirdparty/VoroRycroft/voro++-0.4.6/src/voro++.hh"
using namespace voro;


#endif

