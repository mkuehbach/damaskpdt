//##MK::GPLV3

#ifndef __PDT_SYNTHETIC_GRAINMODEL_H__
#define __PDT_SYNTHETIC_GRAINMODEL_H__

#include "PDT_TessellationHdl.h"



struct grain
{
	squat ori;
	p3d cellcenter;
	double cellvolume;
	unsigned int texid;
	vector<int> nbors;

	grain() : ori(squat()), cellcenter(p3d()), cellvolume(0.0), texid(UINT32MX), nbors(vector<int>()) {}
	grain( const unsigned int _id, squat const & in ) : ori(squat(in.q0, in.q1, in.q2, in.q3)), cellcenter(p3d()), cellvolume(0.0),
			texid(_id), nbors(vector<int>()) {}
	grain( const unsigned int _id, squat const & in, p3d const & _cellc, const double _cellvol ) :
		ori(squat(in.q0, in.q1, in.q2, in.q3)), cellcenter(p3d(_cellc.x, _cellc.y, _cellc.z)), cellvolume(_cellvol),
		texid(_id), nbors(vector<int>()) {}
};

ostream& operator<<(ostream& in, grain const & val);


class grainAggregate
{
public:
	grainAggregate();
	~grainAggregate();

	vector<grain> grains;
};

#endif

